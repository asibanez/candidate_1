# Northshore Underwriting Referral Agent

A LangGraph agent, behind a FastAPI service, that reviews homeowners (HO-3) applications referred by the rating engine and returns **APPROVE / DECLINE / REFER / REQUEST_INFO**. Every decision cites the guideline sections behind it, and every run is logged so the decision can be explained afterwards.

**Design in one line: the LLM reads and writes, code decides.** The LLM chooses and calls the enterprise services, turns messy free text (agent notes, inspection narratives) into facts with quotes, and writes the explanation. The source hierarchy (9.1–9.3) and the rules (sections 1–7, precedence 0.1) are deterministic code. That makes the verdict exact and testable, gives the same answer on every run, and makes it hard to steer with prompt injection.

```
intake → screen → investigate ⇄ tools → coverage_guard → extract → reconcile → evaluate → decide → explain → [human_review] → finalize
```

| Node | What it does | LLM? |
|---|---|---|
| `intake` | Validates the case and starts the run log | – |
| `screen` | Regex screen of agent notes for embedded instructions (10.1) and non-permitted factors (8.1). This screen can't be argued with. | – |
| `investigate` ⇄ `tools` | Tool-calling loop: the LLM picks which services to call (property, claims, cat-risk, inspection). Calls run in parallel, with retry and backoff on 503s. The LLM sees **only the structured application**, never the free-text notes, so text in the notes can't steer it. | ✔ |
| `coverage_guard` | Deterministic check that every required service was actually consulted. Anything skipped gets called directly, and the skip is logged. | – |
| `extract` | Reads agent notes and the inspection text into typed facts. Every fact must carry a **verbatim quote**, and facts whose quote isn't in the source are dropped. Also catches paraphrased injections and non-permitted factors. | ✔ |
| `reconcile` | Builds every fact from every source and picks the most authoritative one per 9.1: inspection > third-party > application > notes | – |
| `evaluate` | Rule engine for sections 1–7 and 9.3. Applies 9.2 by **counterfactual re-evaluation**: if the application and notes disagree and the answer would change the decision, the result is REQUEST_INFO. | – |
| `decide` | Precedence 0.1, citations, missing info, compliance flags | – |
| `explain` | Rewrites the reasons in plain language. A rewrite is rejected if it drops a number, mentions a non-permitted factor, or changes the set of sections. | ✔ |
| `human_review` | Optional: pauses a REFER (LangGraph `interrupt`) until an underwriter resumes it via the API | – |

With `LLM_PROVIDER=none` the same graph runs with deterministic stand-ins for the three LLM nodes. That's the **rules-only baseline**. `uw_agent/baseline.py` is a second baseline: **a single LLM call** given the whole guideline document.

---

## Run it on Windows (step by step)

### 1. Install Python (one time)
1. Go to <https://www.python.org/downloads/windows/> and install **Python 3.12** (3.10 or newer works).
2. On the first installer screen, **tick "Add python.exe to PATH"**, then click *Install Now*.
3. Open **Command Prompt** (Start → type `cmd`) and check: `python --version` should print `Python 3.12.x`.

### 2. Get the code
Unzip `northshore-uw-agent.zip` somewhere simple, e.g. `C:\work\northshore-uw-agent`. In Command Prompt:
```bat
cd C:\work\northshore-uw-agent
```

### 3. Install everything (one time)
Double-click **`setup.bat`**, or run it from Command Prompt. It creates a `.venv` folder, installs the packages, and creates your `.env` settings file. It takes 1–3 minutes.

### 4. Choose the model (edit `.env`)
Open `.env` in Notepad (`notepad .env`). Uncomment **one** option and paste your key:
- **OpenAI:** get a key at <https://platform.openai.com/api-keys>, then set `LLM_PROVIDER=openai`, `OPENAI_API_KEY=sk-...`, `LLM_MODEL=gpt-4.1-mini`
- **Anthropic:** get a key at <https://console.anthropic.com/>, then set `LLM_PROVIDER=anthropic`, `ANTHROPIC_API_KEY=sk-ant-...`
- **Local (free):** install Ollama from <https://ollama.com>, run `ollama pull qwen2.5:7b-instruct`, then set `LLM_PROVIDER=ollama`
- **No model:** leave `LLM_PROVIDER=none` (rules-only mode)

Delete or comment out the line `LLM_PROVIDER=none` if you chose a provider. Save the file.

### 5. Start the two services (two windows, leave both open)
1. Double-click **`start_mock_services.bat`**. You should see `Uvicorn running on http://127.0.0.1:8001`.
2. Double-click **`start_api.bat`**. You should see `Uvicorn running on http://127.0.0.1:8000`.

Check that it works: open <http://localhost:8000/health> in a browser. It shows your model and `"services": {"status": "ok", ...}`.

### 6. Run cases
Open a **third** Command Prompt in the project folder and activate the environment:
```bat
cd C:\work\northshore-uw-agent
.venv\Scripts\activate
```
- All 20 public cases through the API: `python scripts\run_cases.py kit\cases`
- One case: `python scripts\run_cases.py kit\cases\case_012.json`
- Interactive: open <http://localhost:8000/docs> → `POST /v1/underwrite` → *Try it out* → paste a case file → *Execute*. Click **Authorize** first and enter `uw-demo-key`.
- Read a run log in the browser: every response has a `trace_id`. Open `http://localhost:8000/v1/runs/<trace_id>/view?key=uw-demo-key`
- Read a run log in the terminal: `python scripts\show_trace.py latest` (add `--full` to include prompts)

### 7. Run the evaluation
```bat
python -m eval.run_eval --systems rules,agent --repeats 3
python -m eval.run_eval --systems rules,agent,baseline --repeats 1
python -m eval.run_eval --set challenge --systems rules,agent --repeats 1
```
Reports are written to `eval\results\report_*.md`, alongside metrics JSON and a CSV with one row per run.

### 8. Run the tests
```bat
python -m pytest -q
```
The tests need no API key and no running services: they start the mock server in-process and use a scripted fake LLM.

### Live session: new cases
Put the new case files in a folder, e.g. `new_cases\`, and run `python scripts\run_cases.py new_cases`.
If they also give you **new mock-service data**, close the mock-services window and start it with their folder added:
```bat
set DATA_DIRS=data/public,C:\path\to\their\data
start_mock_services.bat
```

### Troubleshooting
| Symptom | Fix |
|---|---|
| `'python' is not recognized` | Reinstall Python with "Add to PATH" ticked, or use `py` instead of `python` |
| `services: unreachable` at /health | `start_mock_services.bat` isn't running |
| `401` from our API | Send header `Authorization: Bearer uw-demo-key` (or set `UW_API_KEY` in `.env`) |
| `mode=llm requested but no LLM provider` | Set `LLM_PROVIDER` and the key in `.env`, then restart `start_api.bat` |
| Port already in use | Close the old window, or change `--port` in the .bat file (and `SERVICES_BASE_URL`) |
| Anthropic/OpenAI model not found | Set `LLM_MODEL` to a model your account has access to |

---

## API

`POST /v1/underwrite` takes the case file unchanged. Auth: `Authorization: Bearer uw-demo-key` (or `X-API-Key`).
Optional query parameters: `hitl=true` pauses REFERs for review; `mode=deterministic|llm` overrides the mode.

The response follows the contract (`case_id, decision, reasons[{guideline_id, explanation}], missing_info, flags`) plus:
`trace_id`, `status` (`COMPLETE` | `PENDING_REVIEW`), `other_findings` (rules that fired but didn't drive the decision, e.g. a REFER under a DECLINE), `notes_for_agent` (flood zone 6.3, conflicts settled by 9.1), `flag_details` (the quoted text behind each flag), `mode`, `guidelines_version`.

| Endpoint | Purpose |
|---|---|
| `GET /health` | Model, guidelines version, mock-service reachability |
| `GET /v1/runs/{trace_id}` · `/view?key=` | Run log as JSON, or as a readable timeline |
| `GET /v1/reviews` | REFER decisions waiting for an underwriter |
| `POST /v1/reviews/{trace_id}` | Resume with `{"decision": "APPROVE\|DECLINE\|REQUEST_INFO", "underwriter_id": "...", "comment": "...", "reasons": [...]}`. The response keeps `agent_recommendation: "REFER"` and the review record. |

Flags: `EMBEDDED_INSTRUCTION`, `NON_PERMITTED_FACTOR_DISREGARDED`, `SERVICE_UNAVAILABLE:<SERVICE>`, `GUIDELINE_GAP`.

## Interpretation choices (where the guidelines leave room)
- **Claims service still down after 6 retries** → REQUEST_INFO citing 9.3, with flag `SERVICE_UNAVAILABLE:CLAIMS`. It never silently approves. A DECLINE established elsewhere still wins, per 0.1.
- **No CLUE report on file (404)** → treated as no prior claims, and the run log says so.
- **Disclosure matching (3.4)** → a counted claim counts as disclosed if the application lists one with the same loss type and year.
- **Roof material not covered by section 2** (e.g. wood shake) → REFER with flag `GUIDELINE_GAP`, rather than guessing.
- **Optional items with unknown presence** (pool, stove, tank, trampoline) are treated as absent. Once an item is present, its details are required (9.3). Unknown dog bite history and unknown diving board (when a pool exists) → REQUEST_INFO.
- **Unoccupied "more than 60 days"** → `months_unoccupied > 2`.
- **Concerns in the notes that aren't a clean fact** ("rents it out some weekends") → REQUEST_INFO under 9.2, unless an inspection or third-party source already settles that point.

## Repository layout
```
uw_agent/   graph.py (LangGraph), rules.py, facts.py, text_facts.py, screening.py, services.py, llm.py,
            api.py (FastAPI), agent.py, baseline.py, tracing.py, guidelines.py, config.py
eval/       run_eval.py, results/, challenge/ (12 extra cases + mock data + our labels)
scripts/    run_cases.py, show_trace.py, draw_graph.py
tests/      63 tests: rules, graph LLM path (fake model), guards, outages, HITL, API contract
kit/        the exercise kit as provided (cases, labels, guidelines, mock services)
runs/       one JSONL log per run (created at runtime)
```
