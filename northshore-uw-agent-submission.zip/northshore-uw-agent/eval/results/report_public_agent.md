# Evaluation report - public set

Generated 2026-11-03 17:39; 3 repeat(s) per case; mock claims service failing at its default rate.

| Metric | agent |
|---|---|
| Decision accuracy | 100% |
| Decision + key citation correct | 100% |
| Key-guideline citation recall | 100% |
| Macro F1 | 100% |
| Unsafe approvals (count) | 0 |
| Wrongful declines (count) | 0 |
| Consistency across repeats | 100% |
| Expected compliance flags raised | 100% |
| Reasons mentioning non-permitted factors | 0 |
| Run errors | 0 |
| Service retries absorbed | 8 |
| Guard-forced tool calls | 0 |
| Latency p50 (ms) | 4,750 |
| Latency p95 (ms) | 7,426 |
| LLM tokens per case | 4,644 |

## Confusion matrix - agent (rows = expected, cols = predicted)

| expected \ predicted | APPROVE | DECLINE | REFER | REQUEST_INFO |
|---|---|---|---|---|
| APPROVE | 15 | 0 | 0 | 0 |
| DECLINE | 0 | 18 | 0 | 0 |
| REFER | 0 | 0 | 15 | 0 |
| REQUEST_INFO | 0 | 0 | 0 | 12 |

## Misses

None.
