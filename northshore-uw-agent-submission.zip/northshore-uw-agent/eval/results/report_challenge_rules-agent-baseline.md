# Evaluation report - challenge set

Generated 2026-11-03 15:13; 1 repeat(s) per case; mock claims service failing at its default rate.

| Metric | rules | agent | baseline |
|---|---|---|---|
| Decision accuracy | 83% | 92% | 83% |
| Decision + key citation correct | 83% | 92% | 75% |
| Key-guideline citation recall | 91% | 100% | 82% |
| Macro F1 | 77% | 93% | 77% |
| Unsafe approvals (count) | 1 | 0 | 2 |
| Wrongful declines (count) | 0 | 0 | 0 |
| Consistency across repeats | 100% | 100% | 100% |
| Expected compliance flags raised | 100% | 100% | 0% |
| Reasons mentioning non-permitted factors | 0 | 0 | 2 |
| Run errors | 0 | 0 | 0 |
| Service retries absorbed | 2 | 0 | 0 |
| Guard-forced tool calls | 0 | 0 | 0 |
| Latency p50 (ms) | 1,726 | 5,736 | 3,702 |
| Latency p95 (ms) | 2,358 | 9,533 | 6,250 |
| LLM tokens per case | 0 | 4,501 | 2,875 |

## Confusion matrix - rules (rows = expected, cols = predicted)

| expected \ predicted | APPROVE | DECLINE | REFER | REQUEST_INFO |
|---|---|---|---|---|
| APPROVE | 1 | 0 | 0 | 0 |
| DECLINE | 0 | 5 | 0 | 1 |
| REFER | 0 | 0 | 3 | 0 |
| REQUEST_INFO | 1 | 0 | 0 | 1 |

## Confusion matrix - agent (rows = expected, cols = predicted)

| expected \ predicted | APPROVE | DECLINE | REFER | REQUEST_INFO |
|---|---|---|---|---|
| APPROVE | 1 | 0 | 0 | 0 |
| DECLINE | 0 | 5 | 0 | 1 |
| REFER | 0 | 0 | 3 | 0 |
| REQUEST_INFO | 0 | 0 | 0 | 2 |

## Confusion matrix - baseline (rows = expected, cols = predicted)

| expected \ predicted | APPROVE | DECLINE | REFER | REQUEST_INFO |
|---|---|---|---|---|
| APPROVE | 1 | 0 | 0 | 0 |
| DECLINE | 1 | 5 | 0 | 0 |
| REFER | 0 | 0 | 3 | 0 |
| REQUEST_INFO | 1 | 0 | 0 | 1 |

## Misses

- **rules** ch_010 (repeat 0): predicted REQUEST_INFO citing ['4.4'], expected DECLINE ['4.4'] - trace `ad03b979853c4c74`
- **rules** ch_012 (repeat 0): predicted APPROVE citing [], expected REQUEST_INFO ['9.2'] - trace `420bd322f9b74038`
- **agent** ch_010 (repeat 0): predicted REQUEST_INFO citing ['4.4'], expected DECLINE ['4.4'] - trace `3c111d19d283418e`
- **baseline** ch_001 (repeat 0): predicted APPROVE citing ['1.1', '1.2', '1.3', '1.4', '1.5', '1.6', '2.1', '3.1', '4.1', '4.3', '5.1', '6.1', '7.2'], expected DECLINE ['1.2'] - trace `932ab7047d69457b`
- **baseline** ch_007 (repeat 0): predicted REQUEST_INFO citing ['2.2'], expected REQUEST_INFO ['9.2'] - trace `708bc921309145a9`
- **baseline** ch_012 (repeat 0): predicted APPROVE citing ['1.1', '1.2', '1.3', '1.4', '1.5', '1.6', '2.1', '3.1', '4.1', '4.3', '4.4', '5.1', '6.1', '7.2'], expected REQUEST_INFO ['9.2'] - trace `d355beac5df14a4b`
