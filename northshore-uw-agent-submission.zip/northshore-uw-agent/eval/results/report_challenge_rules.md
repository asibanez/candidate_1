# Evaluation report - challenge set

Generated 2026-11-03 10:41; 1 repeat(s) per case; mock claims service failing at its default rate.

| Metric | rules |
|---|---|
| Decision accuracy | 83% |
| Decision + key citation correct | 83% |
| Key-guideline citation recall | 91% |
| Macro F1 | 77% |
| Unsafe approvals (count) | 1 |
| Wrongful declines (count) | 0 |
| Consistency across repeats | 100% |
| Expected compliance flags raised | 100% |
| Reasons mentioning non-permitted factors | 0 |
| Run errors | 0 |
| Service retries absorbed | 2 |
| Guard-forced tool calls | 0 |
| Latency p50 (ms) | 792 |
| Latency p95 (ms) | 1,681 |
| LLM tokens per case | 0 |

## Confusion matrix - rules (rows = expected, cols = predicted)

| expected \ predicted | APPROVE | DECLINE | REFER | REQUEST_INFO |
|---|---|---|---|---|
| APPROVE | 1 | 0 | 0 | 0 |
| DECLINE | 0 | 5 | 0 | 1 |
| REFER | 0 | 0 | 3 | 0 |
| REQUEST_INFO | 1 | 0 | 0 | 1 |

## Misses

- **rules** ch_010 (repeat 0): predicted REQUEST_INFO citing ['4.4'], expected DECLINE ['4.4'] - trace `f4ca990b13eb4e19`
- **rules** ch_012 (repeat 0): predicted APPROVE citing [], expected REQUEST_INFO ['9.2'] - trace `0172870569cc4e76`
