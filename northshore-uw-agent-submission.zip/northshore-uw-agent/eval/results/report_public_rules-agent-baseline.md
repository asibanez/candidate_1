# Evaluation report - public set

Generated 2026-11-03 14:26; 3 repeat(s) per case; mock claims service failing at its default rate.

| Metric | rules | agent | baseline |
|---|---|---|---|
| Decision accuracy | 100% | 100% | 80% |
| Decision + key citation correct | 100% | 100% | 75% |
| Key-guideline citation recall | 100% | 100% | 82% |
| Macro F1 | 100% | 100% | 80% |
| Unsafe approvals (count) | 0 | 0 | 0 |
| Wrongful declines (count) | 0 | 0 | 3 |
| Consistency across repeats | 100% | 100% | 90% |
| Expected compliance flags raised | 100% | 100% | 50% |
| Reasons mentioning non-permitted factors | 0 | 0 | 1 |
| Run errors | 0 | 0 | 0 |
| Service retries absorbed | 8 | 11 | 19 |
| Guard-forced tool calls | 0 | 0 | 0 |
| Latency p50 (ms) | 1,208 | 5,696 | 4,328 |
| Latency p95 (ms) | 2,380 | 8,219 | 6,623 |
| LLM tokens per case | 0 | 4,412 | 2,883 |

## Confusion matrix - rules (rows = expected, cols = predicted)

| expected \ predicted | APPROVE | DECLINE | REFER | REQUEST_INFO |
|---|---|---|---|---|
| APPROVE | 15 | 0 | 0 | 0 |
| DECLINE | 0 | 18 | 0 | 0 |
| REFER | 0 | 0 | 15 | 0 |
| REQUEST_INFO | 0 | 0 | 0 | 12 |

## Confusion matrix - agent (rows = expected, cols = predicted)

| expected \ predicted | APPROVE | DECLINE | REFER | REQUEST_INFO |
|---|---|---|---|---|
| APPROVE | 15 | 0 | 0 | 0 |
| DECLINE | 0 | 18 | 0 | 0 |
| REFER | 0 | 0 | 15 | 0 |
| REQUEST_INFO | 0 | 0 | 0 | 12 |

## Confusion matrix - baseline (rows = expected, cols = predicted)

| expected \ predicted | APPROVE | DECLINE | REFER | REQUEST_INFO |
|---|---|---|---|---|
| APPROVE | 11 | 3 | 0 | 1 |
| DECLINE | 0 | 12 | 3 | 3 |
| REFER | 0 | 0 | 13 | 2 |
| REQUEST_INFO | 0 | 0 | 0 | 12 |

## Misses

- **baseline** case_002 (repeat 0): predicted REQUEST_INFO citing ['2.2'], expected DECLINE ['2.3'] - trace `3628ab13fc5f4457`
- **baseline** case_003 (repeat 0): predicted DECLINE citing ['2.3', '2.2', '2.3'], expected APPROVE [] - trace `85d68a7c884440dc`
- **baseline** case_005 (repeat 0): predicted REFER citing ['3.1'], expected DECLINE ['3.1'] - trace `2db4fa11623847c2`
- **baseline** case_007 (repeat 0): predicted REFER citing ['3.2'], expected REFER ['3.4'] - trace `a27fffb3564c4554`
- **baseline** case_015 (repeat 0): predicted REQUEST_INFO citing ['3'], expected REFER ['7.1'] - trace `c3ab92aa12e84f0e`
- **baseline** case_002 (repeat 1): predicted REQUEST_INFO citing ['2.2'], expected DECLINE ['2.3'] - trace `62cc6aab937143b5`
- **baseline** case_003 (repeat 1): predicted DECLINE citing ['2.3', '0.1'], expected APPROVE [] - trace `12bc845c28564df9`
- **baseline** case_005 (repeat 1): predicted REFER citing ['3.1'], expected DECLINE ['3.1'] - trace `c4db18fb35894d2f`
- **baseline** case_007 (repeat 1): predicted REFER citing ['3.2'], expected REFER ['3.4'] - trace `94fd11d9eab94041`
- **baseline** case_001 (repeat 2): predicted REQUEST_INFO citing ['3'], expected APPROVE [] - trace `12c1ffed12cf4ca6`
- **baseline** case_002 (repeat 2): predicted REQUEST_INFO citing ['2.2'], expected DECLINE ['2.3'] - trace `0f6d442d10f14757`
- **baseline** case_003 (repeat 2): predicted DECLINE citing ['2.3', '2.2', '2.3'], expected APPROVE [] - trace `b49e322a0e064698`
- **baseline** case_005 (repeat 2): predicted REFER citing ['3.1'], expected DECLINE ['3.1'] - trace `1d35c057f88948bd`
- **baseline** case_007 (repeat 2): predicted REFER citing ['3.2'], expected REFER ['3.4'] - trace `566f987f8dcb4619`
- **baseline** case_015 (repeat 2): predicted REQUEST_INFO citing ['3'], expected REFER ['7.1'] - trace `9e680993fe314653`
