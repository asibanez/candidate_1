"""Automated evaluation on labeled cases.

    python -m eval.run_eval                                # rules-only + agent (if an LLM is configured)
    python -m eval.run_eval --systems rules,agent,baseline --repeats 3
    python -m eval.run_eval --set challenge                # our extra cases (needs challenge mock data loaded)
    python -m eval.run_eval --url http://localhost:8000    # evaluate the running API instead of in-process

Metrics (why each one matters):
  decision_accuracy     - exact match of the 4-way decision; the headline number.
  macro_f1 / per-class  - the classes are imbalanced (5 APPROVE vs 6 DECLINE...), so accuracy alone can hide a weak class.
  key_citation_recall   - did we cite the sections that drive the label? A right answer for the wrong reason fails 0.2.
  strict_accuracy       - decision correct AND key citations present.
  unsafe_approvals      - APPROVE when the label is anything else. The costliest error: binds a risk nobody checked.
  wrongful_declines     - DECLINE when the label is not DECLINE. Customer harm and regulatory exposure.
  consistency           - same decision on every repeat, with the claims service failing ~15% of the time.
  compliance            - EMBEDDED_INSTRUCTION flagged where expected; zero non-permitted factors in any reason text.
  latency / tokens      - cost of the approach.
"""
from __future__ import annotations

import argparse
import csv
import json
import statistics
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from uw_agent.screening import find_non_permitted  # noqa: E402

CLASSES = ["APPROVE", "DECLINE", "REFER", "REQUEST_INFO"]
SETS = {
    "public": (ROOT / "kit/cases", ROOT / "kit/labels/labels_public.json"),
    "challenge": (ROOT / "eval/challenge/cases", ROOT / "eval/challenge/labels_challenge.json"),
}
EXPECTED_FLAGS = {"case_012": "EMBEDDED_INSTRUCTION", "ch_006": "EMBEDDED_INSTRUCTION",
                  "case_011": "NON_PERMITTED_FACTOR_DISREGARDED"}


def load(set_name):
    cdir, lpath = SETS[set_name]
    labels = {l["case_id"]: l for l in json.loads(lpath.read_text(encoding="utf-8"))}
    cases = [json.loads(p.read_text(encoding="utf-8")) for p in sorted(cdir.glob("*.json"))]
    return cases, labels


def runner(system: str, url: str | None):
    if url:
        import httpx

        key = __import__("os").getenv("UW_API_KEY", "uw-demo-key")
        mode = {"agent": "llm", "rules": "deterministic"}[system]

        def call(case):
            r = httpx.post(f"{url}/v1/underwrite", params={"mode": mode}, json=case,
                           headers={"Authorization": f"Bearer {key}"}, timeout=180)
            r.raise_for_status()
            return r.json()

        return call
    if system == "baseline":
        from uw_agent.baseline import run_baseline

        return run_baseline
    from uw_agent.agent import run_case

    mode = {"agent": "llm", "rules": "deterministic"}[system]
    return lambda case: run_case(case, mode=mode, hitl=False)


def trace_stats(trace_id: str) -> dict:
    from uw_agent.tracing import read_trace

    try:
        ev = read_trace(trace_id)
    except Exception:
        return {}
    tok = sum((e.get("usage") or {}).get("total_tokens", 0) or 0 for e in ev if e["event"] == "llm_call")
    calls = [e for e in ev if e["event"] == "tool_call"]
    return {
        "llm_calls": sum(e["event"] == "llm_call" for e in ev),
        "tokens": tok,
        "tool_calls": len(calls),
        "retries": sum(max(0, (e.get("attempts") or 1) - 1) for e in calls),
        "guard_forced": sum(e["event"] == "guard" and e.get("kind") == "forced_tool_calls" for e in ev),
        "fallbacks": sum(e["event"] == "fallback" for e in ev),
        "dropped_extractions": sum(len(e.get("dropped", [])) for e in ev if e.get("kind") == "dropped_extractions"),
    }


def evaluate_system(system, cases, labels, repeats, url):
    call = runner(system, url)
    rows = []
    for rep in range(repeats):
        for case in cases:
            cid = case["case_id"]
            lab = labels[cid]
            t0 = time.perf_counter()
            try:
                resp = call(case)
                err = None
            except Exception as e:  # a crash is a failed case, not a crashed eval
                resp, err = {"decision": "ERROR", "reasons": [], "flags": [], "missing_info": []}, f"{type(e).__name__}: {e}"
            ms = (time.perf_counter() - t0) * 1000
            cited = [r["guideline_id"] for r in resp.get("reasons", [])]
            reason_text = " ".join(r.get("explanation", "") for r in resp.get("reasons", []))
            row = {
                "system": system, "repeat": rep, "case_id": cid, "expected": lab["decision"], "predicted": resp["decision"],
                "correct": resp["decision"] == lab["decision"], "key": lab["key_guidelines"], "cited": cited,
                "key_cited": set(lab["key_guidelines"]) <= set(cited),
                "flags": resp.get("flags", []), "missing_info": resp.get("missing_info", []),
                "leaked_factors": sorted({f["category"] for f in find_non_permitted(reason_text)}),
                "latency_ms": round(ms), "error": err, "trace_id": resp.get("trace_id"),
            }
            row["strict"] = row["correct"] and row["key_cited"]
            if not url and resp.get("trace_id"):
                row.update(trace_stats(resp["trace_id"]))
            rows.append(row)
            mark = "ok " if row["strict"] else "XX "
            print(f"  [{system} r{rep}] {mark}{cid}: {row['predicted']:<12} cites {cited}  (expected {lab['decision']} {lab['key_guidelines']})"
                  + (f"  ERROR {err}" if err else ""))
    return rows


def metrics(rows):
    n = len(rows)
    m = {"runs": n, "cases": len({r["case_id"] for r in rows})}
    m["decision_accuracy"] = sum(r["correct"] for r in rows) / n
    m["strict_accuracy"] = sum(r["strict"] for r in rows) / n
    with_key = [r for r in rows if r["key"]]
    m["key_citation_recall"] = sum(r["key_cited"] for r in with_key) / len(with_key) if with_key else None
    m["unsafe_approvals"] = sum(r["predicted"] == "APPROVE" and r["expected"] != "APPROVE" for r in rows)
    m["wrongful_declines"] = sum(r["predicted"] == "DECLINE" and r["expected"] != "DECLINE" for r in rows)
    m["errors"] = sum(bool(r["error"]) for r in rows)
    per = {}
    f1s = []
    for c in CLASSES:
        tp = sum(r["predicted"] == c and r["expected"] == c for r in rows)
        fp = sum(r["predicted"] == c and r["expected"] != c for r in rows)
        fn = sum(r["predicted"] != c and r["expected"] == c for r in rows)
        p = tp / (tp + fp) if tp + fp else 0.0
        rc = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2 * p * rc / (p + rc) if p + rc else 0.0
        per[c] = {"precision": round(p, 3), "recall": round(rc, 3), "f1": round(f1, 3), "support": tp + fn}
        if tp + fn:
            f1s.append(f1)
    m["per_class"] = per
    m["macro_f1"] = sum(f1s) / len(f1s)
    conf = {e: {p: 0 for p in CLASSES + ["ERROR"]} for e in CLASSES}
    for r in rows:
        conf[r["expected"]][r["predicted"] if r["predicted"] in conf[r["expected"]] else "ERROR"] += 1
    m["confusion"] = conf
    by_case = defaultdict(set)
    for r in rows:
        by_case[r["case_id"]].add(r["predicted"])
    m["consistency"] = sum(len(v) == 1 for v in by_case.values()) / len(by_case)
    exp_flag = [r for r in rows if r["case_id"] in EXPECTED_FLAGS]
    m["expected_flags_raised"] = (sum(EXPECTED_FLAGS[r["case_id"]] in r["flags"] for r in exp_flag) / len(exp_flag)) if exp_flag else None
    m["reasons_mentioning_non_permitted_factors"] = sum(bool(r["leaked_factors"]) for r in rows)
    lat = sorted(r["latency_ms"] for r in rows)
    m["latency_ms_p50"] = statistics.median(lat)
    m["latency_ms_p95"] = lat[min(len(lat) - 1, int(0.95 * len(lat)))]
    for k in ("tokens", "llm_calls", "retries", "guard_forced", "fallbacks", "dropped_extractions"):
        vals = [r.get(k, 0) or 0 for r in rows]
        m[f"{k}_total"] = sum(vals)
    m["tokens_per_case"] = m["tokens_total"] / n
    return m


def report_md(all_metrics, rows, set_name, repeats):
    L = [f"# Evaluation report - {set_name} set", "",
         f"Generated {time.strftime('%Y-%m-%d %H:%M')}; {repeats} repeat(s) per case; mock claims service failing at its default rate.", "",
         "| Metric | " + " | ".join(all_metrics) + " |", "|---|" + "---|" * len(all_metrics)]
    pct = {"decision_accuracy", "strict_accuracy", "key_citation_recall", "macro_f1", "consistency", "expected_flags_raised"}

    def fmt(v, k):
        if v is None:
            return "n/a"
        return f"{v:.0%}" if k in pct else (f"{v:,.0f}" if isinstance(v, (int, float)) else str(v))
    for k, label in [("decision_accuracy", "Decision accuracy"), ("strict_accuracy", "Decision + key citation correct"),
                     ("key_citation_recall", "Key-guideline citation recall"), ("macro_f1", "Macro F1"),
                     ("unsafe_approvals", "Unsafe approvals (count)"), ("wrongful_declines", "Wrongful declines (count)"),
                     ("consistency", "Consistency across repeats"), ("expected_flags_raised", "Expected compliance flags raised"),
                     ("reasons_mentioning_non_permitted_factors", "Reasons mentioning non-permitted factors"),
                     ("errors", "Run errors"), ("retries_total", "Service retries absorbed"), ("guard_forced_total", "Guard-forced tool calls"),
                     ("latency_ms_p50", "Latency p50 (ms)"), ("latency_ms_p95", "Latency p95 (ms)"), ("tokens_per_case", "LLM tokens per case")]:
        L.append(f"| {label} | " + " | ".join(fmt(m.get(k), k) for m in all_metrics.values()) + " |")
    for sysname, m in all_metrics.items():
        L += ["", f"## Confusion matrix - {sysname} (rows = expected, cols = predicted)", "",
              "| expected \\ predicted | " + " | ".join(CLASSES) + " |", "|---|" + "---|" * len(CLASSES)]
        for e in CLASSES:
            L.append(f"| {e} | " + " | ".join(str(m["confusion"][e][p]) for p in CLASSES) + " |")
    misses = [r for r in rows if not r["strict"]]
    L += ["", "## Misses", ""]
    if not misses:
        L.append("None.")
    for r in misses:
        L.append(f"- **{r['system']}** {r['case_id']} (repeat {r['repeat']}): predicted {r['predicted']} citing {r['cited']}, "
                 f"expected {r['expected']} {r['key']}" + (f" - error: {r['error']}" if r["error"] else "") + f" - trace `{r['trace_id']}`")
    return "\n".join(L) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--systems", default=None, help="comma list of: rules, agent, baseline")
    ap.add_argument("--set", default="public", choices=list(SETS))
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--url", default=None, help="evaluate a running API instead of in-process")
    ap.add_argument("--out", default=str(ROOT / "eval/results"))
    a = ap.parse_args()
    from uw_agent.config import get_settings

    systems = a.systems.split(",") if a.systems else (["rules", "agent"] if get_settings().llm_enabled else ["rules"])
    if any(s in ("agent", "baseline") for s in systems) and not get_settings().llm_enabled and not a.url:
        sys.exit("agent/baseline need an LLM: set LLM_PROVIDER and the provider's API key (see README)")
    cases, labels = load(a.set)
    all_rows, all_m = [], {}
    for s in systems:
        print(f"\n== {s} ({len(cases)} cases x {a.repeats})")
        rows = evaluate_system(s, cases, labels, a.repeats, a.url)
        all_rows += rows
        all_m[s] = metrics(rows)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    tag = f"{a.set}_{'-'.join(systems)}"
    (out / f"metrics_{tag}.json").write_text(json.dumps(all_m, indent=2), encoding="utf-8")
    with (out / f"runs_{tag}.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(all_rows[0].keys()))
        w.writeheader()
        for r in all_rows:
            w.writerow({k: (json.dumps(v) if isinstance(v, (list, dict)) else v) for k, v in r.items()})
    md = report_md(all_m, all_rows, a.set, a.repeats)
    (out / f"report_{tag}.md").write_text(md, encoding="utf-8")
    print("\n" + md)
    print(f"Saved to {out}")


if __name__ == "__main__":
    main()
