"""Print a readable timeline of one run (for walking through a decision).

    python scripts/show_trace.py <trace_id>          # from the runs/ folder
    python scripts/show_trace.py latest              # most recent run
    python scripts/show_trace.py latest --full       # include prompts / raw payloads
"""
import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("trace_id")
    ap.add_argument("--full", action="store_true")
    ap.add_argument("--runs", default=str(ROOT / "runs"))
    a = ap.parse_args()
    runs = Path(a.runs)
    if a.trace_id == "latest":
        files = sorted(runs.glob("*.jsonl"), key=lambda p: p.stat().st_mtime)
        if not files:
            sys.exit("no runs yet")
        path = files[-1]
    else:
        path = runs / f"{a.trace_id}.jsonl"
    events = [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]
    for e in events:
        ev, node, t = e["event"], e.get("node") or "", f"{e['elapsed_ms']:>8.0f}ms"
        if ev in ("node_start",):
            continue
        if ev == "node_end":
            print(f"{t}  {node:<15} done ({e['ms']} ms)")
            if a.full:
                print("            output:", json.dumps(e.get("output"))[:600])
        elif ev == "run_start":
            print(f"{t}  RUN {e['case_id']} | mode={e['mode']} | model={e['model']} | guidelines v{e.get('guidelines_version')}")
            print(f"            agent notes: {e['case'].get('agent_notes')!r}")
        elif ev == "tool_call":
            tries = "" if e["attempts"] == 1 else f" after {e['attempts']} attempts {[x['http_status'] for x in e['attempt_log']]}"
            print(f"{t}  {node:<15} TOOL {e['tool']}({e['args']}) by {e['requested_by']} -> {e['status']}{tries}")
            print(f"            response: {json.dumps(e.get('response'))[:300 if not a.full else 4000]}")
        elif ev == "llm_call":
            u = e.get("usage") or {}
            print(f"{t}  {node:<15} LLM {e['purpose']} [{e['model']}] {e['latency_ms']} ms, tokens={u.get('total_tokens')}"
                  + (f" ERROR {e['error']}" if e.get("error") else ""))
            r = e.get("response") or {}
            if r.get("tool_calls"):
                print("            tool calls requested:", [(c["name"], c["args"]) for c in r["tool_calls"]])
            if e.get("parsed"):
                print("            parsed:", json.dumps(e["parsed"])[:800 if not a.full else 6000])
            if a.full:
                for m in e.get("prompt", []):
                    print(f"            [{m['role']}] {str(m['content'])[:1500]}")
        elif ev == "guard":
            print(f"{t}  {node:<15} GUARD {e['kind']}: " + json.dumps({k: v for k, v in e.items() if k not in
                  ('seq', 'ts', 'elapsed_ms', 'trace_id', 'event', 'node', 'kind')})[:400])
        elif ev == "fallback":
            print(f"{t}  {node:<15} FALLBACK {e.get('reason')}")
        elif ev in ("hitl_pause", "hitl_resume"):
            print(f"{t}  {node:<15} {ev.upper()} {json.dumps(e.get('review') or e.get('decision'))}")
        elif ev == "run_end":
            r = e["response"]
            print(f"{t}  DECISION {r['decision']}  flags={r['flags']}")
            for x in r["reasons"]:
                print(f"            {x['guideline_id']}: {x['explanation']}")
            for m in r["missing_info"]:
                print(f"            missing: {m}")
            for o in r.get("other_findings", []):
                print(f"            also: {o['guideline_id']} {o['outcome']} - {o['explanation']}")
            for n in r.get("notes_for_agent", []):
                print(f"            note: {n}")
            for d in r.get("flag_details", []):
                print(f"            flag: {d['flag']} [{d.get('category') or ''}] from {d['source']}: {d['quote'][:120]!r}")
        elif ev == "run_error":
            print(f"{t}  ERROR {e.get('error')}")


if __name__ == "__main__":
    main()
