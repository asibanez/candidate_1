"""Export the LangGraph structure as Mermaid (paste into mermaid.live, or `mmdc` to render a PNG)."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from uw_agent.graph import get_graph  # noqa: E402

src = get_graph().get_graph().draw_mermaid()
out = ROOT / "docs" / "graph.mmd"
out.parent.mkdir(exist_ok=True)
out.write_text(src, encoding="utf-8")
print(src)
print(f"\nwritten to {out}")
