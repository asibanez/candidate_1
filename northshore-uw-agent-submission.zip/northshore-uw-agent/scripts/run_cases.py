"""Send one case file, or every case in a folder, to the running API and print a summary table.
This is the script to use in the live session when you are handed new cases.

    python scripts/run_cases.py kit/cases/case_012.json
    python scripts/run_cases.py path/to/new_cases_folder
    python scripts/run_cases.py new_cases --hitl          # pause REFER decisions for review
    python scripts/run_cases.py new_cases --mode deterministic

Full responses are saved next to the summary in results/ so you can open any of them.
"""
import argparse
import json
import os
import sys
from pathlib import Path

import httpx


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path")
    ap.add_argument("--url", default=os.getenv("UW_URL", "http://localhost:8000"))
    ap.add_argument("--key", default=os.getenv("UW_API_KEY", "uw-demo-key"))
    ap.add_argument("--hitl", action="store_true")
    ap.add_argument("--mode", choices=["llm", "deterministic"], default=None)
    ap.add_argument("--out", default="results")
    a = ap.parse_args()
    p = Path(a.path)
    files = sorted(p.glob("*.json")) if p.is_dir() else [p]
    if not files:
        sys.exit(f"No .json case files found at {p}")
    out = Path(a.out)
    out.mkdir(exist_ok=True)
    params = {k: v for k, v in (("hitl", str(a.hitl).lower()), ("mode", a.mode)) if v}
    print(f"{'case':<12} {'decision':<13} {'cites':<16} flags / missing info")
    print("-" * 90)
    for f in files:
        case = json.loads(f.read_text(encoding="utf-8"))
        r = httpx.post(f"{a.url}/v1/underwrite", params=params, json=case,
                       headers={"Authorization": f"Bearer {a.key}"}, timeout=180)
        if r.status_code != 200:
            print(f"{case.get('case_id', f.name):<12} HTTP {r.status_code}: {r.text[:200]}")
            continue
        b = r.json()
        (out / f"{b['case_id']}.json").write_text(json.dumps(b, indent=2), encoding="utf-8")
        cites = ",".join(x["guideline_id"] for x in b["reasons"]) or "-"
        extra = " ".join(b["flags"])
        if b["missing_info"]:
            extra += (" | " if extra else "") + "; ".join(b["missing_info"])
        status = " (PENDING_REVIEW)" if b.get("status") == "PENDING_REVIEW" else ""
        print(f"{b['case_id']:<12} {b['decision'] + status:<13} {cites:<16} {extra}")
        for x in b["reasons"]:
            print(f"{'':<12}   {x['guideline_id']}: {x['explanation']}")
        print(f"{'':<12}   trace: {a.url}/v1/runs/{b['trace_id']}/view?key={a.key}")
    print(f"\nFull responses saved in {out.resolve()}")


if __name__ == "__main__":
    main()
