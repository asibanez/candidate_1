# Homeowners Underwriting Referral Agent — Candidate Kit

Northshore Home Insurance, its guidelines, people and data are **fictional and synthetic**.

## Contents

```
cases/                      20 referred applications (application + agent notes), one JSON per case
labels/labels_public.json   Expected decision + key guideline sections for each case
guidelines/                 Homeowners Underwriting Guidelines (the rules your agent applies)
mock_services/              Mock enterprise APIs (FastAPI) + their data
```

## 1. Run the mock services

```bash
cd mock_services
pip install -r requirements.txt
uvicorn server:app --port 8001
# interactive docs: http://localhost:8001/docs
```

Every call except `/health` requires `Authorization: Bearer nshi-dev-key-2026`.

| Endpoint | Returns |
|---|---|
| `GET /property/{property_id}` | Third-party property data: year built, size, roof installation year (from permits; may be null), replacement cost estimate, distance to coast |
| `GET /claims?property_id=…&applicant_id=…` | CLUE-style prior-claims report. **Returns 503 about 15% of the time**, like a real dependency |
| `GET /cat-risk/{property_id}` | Wind tier, FEMA flood zone, wildfire score |
| `GET /inspections/{property_id}` | Latest inspection report, or 404 if none is on file |

Calls add random latency (up to 800 ms). Env vars `CLAIMS_FAILURE_RATE` and `MAX_LATENCY_MS` let you change this locally, but your solution must work with the defaults.

`property_id` and `applicant_id` are in each case's `application`.

## 2. API contract your service must expose

Use any authentication scheme you like and tell us the credentials. The base URL is your choice.

### `POST /v1/underwrite`

**Request body:** the contents of a case file, unchanged: `{"case_id": …, "application": {…}, "agent_notes": "…"}`.

**Response:**

```json
{
  "case_id": "case_002",
  "decision": "APPROVE | DECLINE | REFER | REQUEST_INFO",
  "reasons": [
    {"guideline_id": "2.3", "explanation": "Plain-language reason for the agent and applicant"}
  ],
  "missing_info": ["Required for REQUEST_INFO: what is needed"],
  "flags": ["Items for compliance review, e.g. EMBEDDED_INSTRUCTION"]
}
```

- `reasons` is required for every decision except `APPROVE`. It may be empty for `APPROVE`.
- `missing_info` and `flags` may be empty lists.
- You may add extra fields (e.g., a trace ID).

### Optional, only if you have time

- **Human in the loop.** Make a REFER pause the workflow, and let an underwriter resume it with a final decision through an endpoint of your design.
- **Baseline.** Compare your agent against a simpler approach and tell us which you would put in production.

## 3. Labels

`labels/labels_public.json` gives the expected `decision` and the `key_guidelines` that drive it for each case. Other guideline sections may also legitimately apply. Use the labels however you like to build your evaluation.
