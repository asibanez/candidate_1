"""Northshore Home Insurance - mock enterprise services (fictional).

Run:
    pip install -r requirements.txt
    uvicorn server:app --port 8001

Environment variables:
    MOCK_API_KEY       API key required in the Authorization header (default: nshi-dev-key-2026)
    DATA_DIRS          Comma-separated data folders to load (default: data/public)
    CLAIMS_FAILURE_RATE  Probability that /claims returns 503 (default: 0.15)
    MAX_LATENCY_MS     Upper bound of random latency added to each call (default: 800)
"""
import json
import os
import random
import time
from pathlib import Path
from typing import Optional

from fastapi import Depends, FastAPI, Header, HTTPException, Query

BASE = Path(__file__).parent
API_KEY = os.getenv("MOCK_API_KEY", "nshi-dev-key-2026")
DATA_DIRS = [d.strip() for d in os.getenv("DATA_DIRS", "data/public").split(",") if d.strip()]
CLAIMS_FAILURE_RATE = float(os.getenv("CLAIMS_FAILURE_RATE", "0.15"))
MAX_LATENCY_MS = int(os.getenv("MAX_LATENCY_MS", "800"))

PROPERTIES, CLAIMS, CAT, INSPECTIONS = {}, {}, {}, {}
for d in DATA_DIRS:
    p = Path(d) if Path(d).is_absolute() else BASE / d
    for name, store in [("properties.json", PROPERTIES), ("claims.json", CLAIMS),
                        ("cat_risk.json", CAT), ("inspections.json", INSPECTIONS)]:
        f = p / name
        if f.exists():
            store.update(json.loads(f.read_text()))

app = FastAPI(title="Northshore Home Insurance - Mock Services", version="1.0")


def auth(authorization: Optional[str] = Header(default=None)):
    if authorization != f"Bearer {API_KEY}":
        raise HTTPException(status_code=401, detail="Missing or invalid API key")


def latency():
    if MAX_LATENCY_MS > 0:
        time.sleep(random.uniform(0, MAX_LATENCY_MS) / 1000)


@app.get("/health")
def health():
    return {"status": "ok", "properties_loaded": len(PROPERTIES)}


@app.get("/property/{property_id}", dependencies=[Depends(auth)])
def get_property(property_id: str):
    """Third-party property data: year built, size, roof installation year (from permits),
    replacement cost estimate, distance to coast."""
    latency()
    if property_id not in PROPERTIES:
        raise HTTPException(404, "Property not found")
    return PROPERTIES[property_id]


@app.get("/claims", dependencies=[Depends(auth)])
def get_claims(property_id: str = Query(...), applicant_id: Optional[str] = Query(None)):
    """CLUE-style prior-claims report for a property/applicant. Occasionally unavailable."""
    latency()
    if random.random() < CLAIMS_FAILURE_RATE:
        raise HTTPException(503, "Claims history service temporarily unavailable, retry later")
    if property_id not in CLAIMS:
        raise HTTPException(404, "No report for this property")
    rep = CLAIMS[property_id]
    if applicant_id and rep.get("applicant_id") != applicant_id:
        raise HTTPException(404, "No report for this applicant at this property")
    return rep


@app.get("/cat-risk/{property_id}", dependencies=[Depends(auth)])
def get_cat_risk(property_id: str):
    """Catastrophe exposure: wind tier (1 low - 4 high), FEMA flood zone, wildfire score."""
    latency()
    if property_id not in CAT:
        raise HTTPException(404, "Property not found")
    return CAT[property_id]


@app.get("/inspections/{property_id}", dependencies=[Depends(auth)])
def get_inspection(property_id: str):
    """Most recent property inspection report, if one is on file (404 otherwise)."""
    latency()
    if property_id not in INSPECTIONS:
        raise HTTPException(404, "No inspection on file for this property")
    return INSPECTIONS[property_id]
