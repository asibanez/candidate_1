@echo off
REM One-time setup: creates a virtual environment with Python 3.12 (or 3.11/3.10) and installs everything.
cd /d "%~dp0"
set PYCMD=
for %%V in (3.13 3.12 3.11 3.10) do (if not defined PYCMD (py -%%V --version >nul 2>nul && set PYCMD=py -%%V))
if not defined PYCMD (echo Python 3.10+ not found. Install Python 3.12 from python.org first. & pause & exit /b 1)
echo Using %PYCMD%
%PYCMD% -m venv .venv
if errorlevel 1 (echo Could not create the virtual environment. & pause & exit /b 1)
call .venv\Scripts\activate.bat
python --version
python -m pip install --upgrade pip
pip install -r requirements.txt -r kit\mock_services\requirements.txt
if not exist .env copy .env.example .env
echo.
echo Setup complete. Next: edit .env, then run start_mock_services.bat and start_api.bat
pause
