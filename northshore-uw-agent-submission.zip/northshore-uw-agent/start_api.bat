@echo off
REM Starts the underwriting agent API on port 8000. Docs: http://localhost:8000/docs
cd /d "%~dp0"
call .venv\Scripts\activate.bat
python -m uvicorn uw_agent.api:app --port 8000
pause
