"""Test fixtures: in-process mock services (no network, no latency) and a scripted fake LLM."""
from __future__ import annotations

import importlib.util
import json
import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("RUNS_DIR", str(ROOT / "runs" / "_test"))


def load_mock_app(failure_rate: float = 0.0):
    os.environ["CLAIMS_FAILURE_RATE"] = str(failure_rate)
    os.environ["MAX_LATENCY_MS"] = "0"
    path = ROOT / "kit" / "mock_services" / "server.py"
    spec = importlib.util.spec_from_file_location(f"mock_server_{failure_rate}", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.app


@pytest.fixture()
def mock_services(monkeypatch):
    from fastapi.testclient import TestClient

    from uw_agent import services

    app = load_mock_app(0.0)
    monkeypatch.setattr(services, "CLIENT_FACTORY",
                        lambda: TestClient(app, base_url="http://mock", headers={"Authorization": "Bearer nshi-dev-key-2026"}))
    yield app


@pytest.fixture()
def settings(monkeypatch):
    from uw_agent import config

    s = config.override_settings(llm_provider="none", service_backoff_base_s=0.0)
    yield s
    config._settings = None


def load_case(cid: str) -> dict:
    return json.loads((ROOT / "kit" / "cases" / f"{cid}.json").read_text(encoding="utf-8"))


def labels() -> dict:
    return {l["case_id"]: l for l in json.loads((ROOT / "kit" / "labels" / "labels_public.json").read_text(encoding="utf-8"))}
