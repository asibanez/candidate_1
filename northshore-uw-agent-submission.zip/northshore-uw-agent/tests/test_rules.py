from datetime import date

from uw_agent.rules import count_claims, decide, evaluate, match_disclosures

BASE = {
    "occupancy": "owner_primary", "months_unoccupied": 0, "str_nights_per_year": 0, "existing_damage": False,
    "electrical.knob_and_tube": False, "electrical.panel_type": "circuit_breaker", "electrical.amps": 200,
    "oil_tank.present": False, "coverage_a": 500000, "roof.material": "asphalt_shingle", "roof.age_years": 10,
    "roof.condition": None, "pool.present": False, "trampoline.present": False, "dogs.present": False,
    "dogs.bite_history": False, "heating.primary": "gas_forced_air", "wood_stove.present": False,
    "coast_distance_ft": 15000, "replacement_cost": 500000, "flood_zone": "X",
}
CTX = {"submitted_date": "2026-10-05", "claims": {"status": "ok", "data": {"claims": []}}, "disclosed": []}


def run(**over):
    f = evaluate({**BASE, **over}, CTX)
    return decide(f), {x["section"] for x in f if x["outcome"] == decide(f)}


def test_clean_risk_approves():
    assert run() == ("APPROVE", set())


def test_roof_boundaries():
    assert run(**{"roof.age_years": 15})[0] == "APPROVE"
    assert run(**{"roof.age_years": 16}) == ("REQUEST_INFO", {"2.2"})
    assert run(**{"roof.age_years": 20, "roof.condition": "fair"})[0] == "APPROVE"
    assert run(**{"roof.age_years": 21}) == ("DECLINE", {"2.3"})
    assert run(**{"roof.material": "slate", "roof.age_years": 40})[0] == "APPROVE"
    assert run(**{"roof.material": "slate", "roof.age_years": 41}) == ("DECLINE", {"2.5"})
    assert run(**{"roof.condition": "poor"}) == ("DECLINE", {"2.4"})


def test_coastal_and_authority_boundaries():
    assert run(coast_distance_ft=1000) == ("REFER", {"6.1"})
    assert run(coast_distance_ft=1001, coverage_a=760000, replacement_cost=760000) == ("REFER", {"6.2"})
    assert run(coast_distance_ft=5281, coverage_a=760000, replacement_cost=760000)[0] == "APPROVE"
    assert run(coverage_a=800000, replacement_cost=800000)[0] == "APPROVE"
    assert run(coverage_a=800001, replacement_cost=800000) == ("REFER", {"7.1"})
    assert run(coverage_a=1500001, replacement_cost=1500000) == ("DECLINE", {"1.6"})


def test_insurance_to_value_band():
    assert run(coverage_a=425000)[0] == "APPROVE"  # 85%
    assert run(coverage_a=424000) == ("REQUEST_INFO", {"7.2"})
    assert run(coverage_a=575000)[0] == "APPROVE"  # 115%
    assert run(coverage_a=576000) == ("REQUEST_INFO", {"7.2"})


def test_flood_zone_is_note_only():
    assert run(flood_zone="AE")[0] == "APPROVE"


def test_claims_lookback_and_status():
    claims = [
        {"date_of_loss": "2021-10-05", "type": "wind", "amount": 1, "status": "paid"},   # exactly 5y -> counts
        {"date_of_loss": "2021-10-04", "type": "wind", "amount": 1, "status": "paid"},   # older -> excluded
        {"date_of_loss": "2025-01-01", "type": "water", "amount": 0, "status": "closed_without_payment"},
    ]
    cc = count_claims(claims, date(2026, 10, 5))
    assert len(cc["counted"]) == 1 and len(cc["excluded"]) == 2


def test_disclosure_matching():
    counted = [{"date_of_loss": "2025-03-19", "type": "theft"}, {"date_of_loss": "2023-07-03", "type": "water"}]
    und = match_disclosures(counted, [{"year": 2025, "type": "theft", "amount": 3100}])
    assert [c["type"] for c in und] == ["water"]


def test_liability_and_heating():
    assert run(**{"pool.present": True, "pool.fence_height_ft": 3.5, "pool.self_latching_gate": True,
                  "pool.diving_board_or_slide": False}) == ("DECLINE", {"4.1"})
    assert run(**{"trampoline.present": True, "trampoline.safety_net": True})[0] == "APPROVE"
    assert run(**{"dogs.present": True, "dogs.bite_history": True}) == ("DECLINE", {"4.4"})
    assert run(**{"heating.primary": "wood_stove"}) == ("REFER", {"5.1"})
    assert run(**{"wood_stove.present": True, "wood_stove.professionally_installed": True,
                  "wood_stove.ul_listed": None}) == ("REQUEST_INFO", {"5.2"})


def test_precedence_decline_over_info_over_refer():
    assert run(coast_distance_ft=500, **{"roof.age_years": 25})[0] == "DECLINE"
    assert run(coast_distance_ft=500, **{"electrical.amps": None})[0] == "REQUEST_INFO"


def test_eligibility():
    assert run(occupancy="tenant") == ("DECLINE", {"1.1"})
    assert run(months_unoccupied=3) == ("DECLINE", {"1.1"})
    assert run(str_nights_per_year=31) == ("DECLINE", {"1.2"})
    assert run(**{"electrical.panel_type": "fuse"}) == ("DECLINE", {"1.4"})
    assert run(**{"electrical.amps": 60}) == ("DECLINE", {"1.4"})
    assert run(**{"oil_tank.present": True, "oil_tank.location": "underground", "oil_tank.age_years": None}) == ("DECLINE", {"1.5"})
    assert run(**{"oil_tank.present": True, "oil_tank.location": "basement", "oil_tank.age_years": 40})[0] == "APPROVE"
