from fastapi.testclient import TestClient

from conftest import load_case
from uw_agent.api import app

H = {"Authorization": "Bearer uw-demo-key"}


def test_auth_required(settings, mock_services):
    c = TestClient(app)
    assert c.post("/v1/underwrite", json=load_case("case_001")).status_code == 401


def test_contract_shape(settings, mock_services):
    c = TestClient(app)
    r = c.post("/v1/underwrite", json=load_case("case_016"), headers=H)
    assert r.status_code == 200, r.text
    body = r.json()
    for k in ("case_id", "decision", "reasons", "missing_info", "flags"):
        assert k in body
    assert body["decision"] == "REQUEST_INFO"
    assert body["reasons"][0] == {"guideline_id": "7.2", "explanation": body["reasons"][0]["explanation"]}
    assert c.get(f"/v1/runs/{body['trace_id']}", headers=H).status_code == 200
    assert "Run trace" in c.get(f"/v1/runs/{body['trace_id']}/view?key=uw-demo-key").text


def test_bad_case_is_422(settings, mock_services):
    c = TestClient(app)
    r = c.post("/v1/underwrite", json={"case_id": "x", "application": {}}, headers=H)
    assert r.status_code == 422


def test_review_flow_over_http(settings, mock_services):
    c = TestClient(app)
    body = c.post("/v1/underwrite?hitl=true", json=load_case("case_013"), headers=H).json()
    assert body["status"] == "PENDING_REVIEW" and body["decision"] == "REFER"
    assert any(p["trace_id"] == body["trace_id"] for p in c.get("/v1/reviews", headers=H).json())
    final = c.post(f"/v1/reviews/{body['trace_id']}", headers=H,
                   json={"decision": "DECLINE", "underwriter_id": "UW-2", "comment": "Wind exposure too high",
                         "reasons": [{"guideline_id": "6.1", "explanation": "Underwriter declined coastal risk."}]}).json()
    assert final["decision"] == "DECLINE" and final["agent_recommendation"] == "REFER"
    assert c.post(f"/v1/reviews/{body['trace_id']}", headers=H, json={"decision": "APPROVE", "underwriter_id": "x"}).status_code == 404
