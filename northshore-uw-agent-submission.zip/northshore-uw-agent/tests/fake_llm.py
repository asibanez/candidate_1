"""A scripted stand-in for a chat model, so the LLM path of the graph can be tested without an API key.

It implements the two interfaces the graph uses: .bind_tools(...).invoke(messages) and
.with_structured_output(schema, include_raw=True).invoke(messages).
"""
from __future__ import annotations

import re

from langchain_core.messages import AIMessage, ToolMessage
from langchain_core.runnables import RunnableLambda

from uw_agent.text_facts import TextAnalysis, TextFact, TextFlag, regex_extract
from uw_agent.screening import find_injections, find_non_permitted


class FakeLLM:
    def __init__(self, skip_tools=(), hallucinate=False, fail_extract=False, explain_mode="good", extra_flags=()):
        self.skip_tools = set(skip_tools)
        self.hallucinate = hallucinate
        self.fail_extract = fail_extract
        self.explain_mode = explain_mode
        self.extra_flags = list(extra_flags)
        self.calls = []

    # ---- tool calling (investigate node)
    def bind_tools(self, tools):
        names = [t.name for t in tools]

        def run(messages):
            self.calls.append("investigate")
            if any(isinstance(m, ToolMessage) for m in messages):
                return AIMessage("Gathered property, claims, cat risk and inspection evidence.")
            human = messages[-1].content
            pid = re.search(r'"property_id": "([^"]+)"', human).group(1)
            aid = re.search(r'"applicant_id": "([^"]+)"', human).group(1)
            calls = []
            for i, n in enumerate(names):
                if n in self.skip_tools:
                    continue
                args = {"property_id": pid}
                if n == "get_claims_history":
                    args["applicant_id"] = aid
                calls.append({"name": n, "args": args, "id": f"call_{i}", "type": "tool_call"})
            return AIMessage(content="", tool_calls=calls, usage_metadata={"input_tokens": 900, "output_tokens": 80, "total_tokens": 980})

        return RunnableLambda(run)

    # ---- structured output (extract / explain nodes)
    def with_structured_output(self, schema, include_raw=False):
        def run(messages):
            raw = AIMessage("{}", usage_metadata={"input_tokens": 1200, "output_tokens": 150, "total_tokens": 1350})
            if schema is TextAnalysis:
                self.calls.append("extract")
                if self.fail_extract:
                    raise RuntimeError("simulated provider error")
                doc = re.search(r"<document>\n(.*)\n</document>", messages[-1].content, re.S).group(1)
                year = int(re.search(r"submitted (\d{4})", messages[-1].content).group(1))
                facts = [TextFact(fact=f["fact"], value=str(f["value"]).lower(), quote=f["quote"]) for f in regex_extract(doc, "x", year)]
                if self.hallucinate:
                    facts.append(TextFact(fact="existing_damage", value="true", quote="the basement floods every spring"))
                flags = [TextFlag(kind="embedded_instruction", quote=f["quote"]) for f in find_injections(doc)]
                flags += [TextFlag(kind="non_permitted_factor", category=f["category"], quote=f["quote"]) for f in find_non_permitted(doc)]
                flags += [TextFlag(**f) for f in self.extra_flags if f["quote"] in doc]
                parsed = TextAnalysis(facts=facts, flags=flags)
            else:  # explanations
                self.calls.append("explain")
                import json

                items = json.loads(messages[-1].content.split("Items:\n", 1)[1])
                if self.explain_mode == "drop_numbers":
                    out = [{"guideline_id": i["guideline_id"], "explanation": "Your application does not meet our rules."} for i in items]
                else:
                    out = [{"guideline_id": i["guideline_id"], "explanation": "In plain terms: " + i["draft_reason"]} for i in items]
                parsed = schema.model_validate({"items": out})
            return {"raw": raw, "parsed": parsed, "parsing_error": None} if include_raw else parsed

        return RunnableLambda(run)
