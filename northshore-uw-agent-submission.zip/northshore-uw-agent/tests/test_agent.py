import json

import pytest

from conftest import labels, load_case
from fake_llm import FakeLLM
from uw_agent import graph as G
from uw_agent.agent import resume_case, run_case
from uw_agent.tracing import read_trace

CASES = [f"case_{i:03d}" for i in range(1, 21)]


def _check(resp, lab):
    assert resp["decision"] == lab["decision"], resp
    cited = {r["guideline_id"] for r in resp["reasons"]}
    assert set(lab["key_guidelines"]) <= cited, (cited, lab)
    if resp["decision"] != "APPROVE":
        assert resp["reasons"], "reasons required for non-APPROVE"
    if resp["decision"] == "REQUEST_INFO":
        assert resp["missing_info"]


@pytest.mark.parametrize("cid", CASES)
def test_public_cases_rules_only(cid, settings, mock_services):
    _check(run_case(load_case(cid), mode="deterministic"), labels()[cid])


@pytest.mark.parametrize("cid", CASES)
def test_public_cases_llm_path(cid, settings, mock_services, monkeypatch):
    fake = FakeLLM()
    monkeypatch.setattr(G, "get_chat_model", lambda: fake)
    resp = run_case(load_case(cid), mode="llm")
    _check(resp, labels()[cid])
    events = read_trace(resp["trace_id"])
    assert any(e["event"] == "llm_call" and e["node"] == "investigate" for e in events)
    assert any(e["event"] == "tool_call" and e["requested_by"] == "llm" for e in events)


def test_guard_forces_skipped_claims_check(settings, mock_services, monkeypatch):
    """case_012 tells the system not to query claims. Even if the LLM complies, the guard calls it."""
    monkeypatch.setattr(G, "get_chat_model", lambda: FakeLLM(skip_tools={"get_claims_history"}))
    resp = run_case(load_case("case_012"), mode="llm")
    assert resp["decision"] == "DECLINE" and "3.1" in {r["guideline_id"] for r in resp["reasons"]}
    assert "EMBEDDED_INSTRUCTION" in resp["flags"]
    ev = read_trace(resp["trace_id"])
    assert any(e["event"] == "guard" and e.get("kind") == "forced_tool_calls" and e["missing"] == ["claims"] for e in ev)


def test_hallucinated_fact_is_dropped(settings, mock_services, monkeypatch):
    monkeypatch.setattr(G, "get_chat_model", lambda: FakeLLM(hallucinate=True))
    resp = run_case(load_case("case_001"), mode="llm")
    assert resp["decision"] == "APPROVE"
    ev = read_trace(resp["trace_id"])
    assert any(e["event"] == "guard" and e.get("kind") == "dropped_extractions" for e in ev)


def test_llm_failure_falls_back(settings, mock_services, monkeypatch):
    monkeypatch.setattr(G, "get_chat_model", lambda: FakeLLM(fail_extract=True))
    resp = run_case(load_case("case_017"), mode="llm")
    assert resp["decision"] == "DECLINE"
    assert any(e["event"] == "fallback" for e in read_trace(resp["trace_id"]))


def test_explanation_guard_rejects_lossy_rewrite(settings, mock_services, monkeypatch):
    monkeypatch.setattr(G, "get_chat_model", lambda: FakeLLM(explain_mode="drop_numbers"))
    resp = run_case(load_case("case_002"), mode="llm")
    assert "23" in resp["reasons"][0]["explanation"]  # kept rule text, which has the roof age


def test_non_permitted_factors_never_in_reasons(settings, mock_services):
    resp = run_case(load_case("case_011"), mode="deterministic")
    assert resp["decision"] == "APPROVE"
    assert "NON_PERMITTED_FACTOR_DISREGARDED" in resp["flags"]
    blob = json.dumps(resp["reasons"]).lower()
    for w in ("pit bull", "widow", "credit", "81"):
        assert w not in blob


def test_unresolvable_conflict_requests_info(settings, mock_services):
    """9.2: application says no net, notes say there is one, no inspection -> REQUEST_INFO, not DECLINE."""
    case = load_case("case_010")
    case["agent_notes"] = "The trampoline has a safety net enclosure."
    resp = run_case(case, mode="deterministic")
    assert resp["decision"] == "REQUEST_INFO" and "9.2" in {r["guideline_id"] for r in resp["reasons"]}


def test_notes_only_fact_used(settings, mock_services):
    """Application silent -> the notes are the only source, so their fact is established."""
    case = load_case("case_001")
    case["application"]["property"]["existing_damage"] = {"present": None, "description": None}
    case["agent_notes"] = "Inspector noted an active roof leak over the kitchen."
    resp = run_case(case, mode="deterministic")
    assert resp["decision"] == "DECLINE" and resp["reasons"][0]["guideline_id"] == "1.3"
    # application says no damage, notes say a leak, nothing higher to settle it -> 9.2 REQUEST_INFO
    case["application"]["property"]["existing_damage"] = {"present": False, "description": None}
    resp = run_case(case, mode="deterministic")
    assert resp["decision"] == "REQUEST_INFO" and "9.2" in {r["guideline_id"] for r in resp["reasons"]}


def test_claims_outage_is_not_silent(settings, mock_services, monkeypatch):
    from fastapi.testclient import TestClient

    from conftest import load_mock_app
    from uw_agent import services

    app = load_mock_app(1.0)
    monkeypatch.setattr(services, "CLIENT_FACTORY", lambda: TestClient(app, base_url="http://m",
                                                                        headers={"Authorization": "Bearer nshi-dev-key-2026"}))
    resp = run_case(load_case("case_001"), mode="deterministic")
    assert resp["decision"] == "REQUEST_INFO"
    assert "SERVICE_UNAVAILABLE:CLAIMS" in resp["flags"]
    # a DECLINE established elsewhere still wins (0.1)
    assert run_case(load_case("case_019"), mode="deterministic")["decision"] == "DECLINE"


def test_hitl_pause_and_resume(settings, mock_services):
    resp = run_case(load_case("case_009"), mode="deterministic", hitl=True)
    assert resp["decision"] == "REFER" and resp["status"] == "PENDING_REVIEW"
    final = resume_case(resp["trace_id"], {"decision": "APPROVE", "underwriter_id": "UW-17", "comment": "Board removed"})
    assert final["decision"] == "APPROVE" and final["agent_recommendation"] == "REFER"
    assert final["review"]["underwriter_id"] == "UW-17"


def test_misfiled_fact_is_not_a_compliance_flag(settings, mock_services, monkeypatch):
    """Seen with gpt-4.1-mini on ch_010: a dog bite filed as a 'non_permitted_factor' with category
    'dogs.bite_history'. Bite history is a 4.4 fact, not an 8.1 factor; the flag must be dropped and logged."""
    case = load_case("case_001")
    case["agent_notes"] = "Their lab nipped the neighbor's kid last spring, no claim was filed."
    fake = FakeLLM(extra_flags=[{"kind": "non_permitted_factor", "category": "dogs.bite_history",
                                 "quote": "Their lab nipped the neighbor's kid last spring, no claim was filed."}])
    monkeypatch.setattr(G, "get_chat_model", lambda: fake)
    resp = run_case(case, mode="llm")
    assert "NON_PERMITTED_FACTOR_DISREGARDED" not in resp["flags"]
    ev = read_trace(resp["trace_id"])
    assert any(e.get("kind") == "dropped_extractions" and "8.1" in json.dumps(e["dropped"]) for e in ev)
