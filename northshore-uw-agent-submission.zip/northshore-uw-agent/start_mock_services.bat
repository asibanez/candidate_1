@echo off
REM Starts the mock enterprise services on port 8001 (public data + our challenge data).
cd /d "%~dp0kit\mock_services"
call "%~dp0.venv\Scripts\activate.bat"
if "%DATA_DIRS%"=="" set DATA_DIRS=data/public,%~dp0eval\challenge\mock_data
echo Loading data from: %DATA_DIRS%
python -m uvicorn server:app --port 8001
pause
