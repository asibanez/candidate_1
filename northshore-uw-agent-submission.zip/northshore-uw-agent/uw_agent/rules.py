"""Deterministic rule engine for the Northshore HO-3 guidelines (v4.2).

Each rule returns findings: {section, outcome, reason, facts_used, missing}.
Outcomes: DECLINE | REFER | REQUEST_INFO | NOTE.  Decision precedence follows 0.1.
Rules are code, not prompts: they are exact, testable, and give the same answer every run.
The LLM's job is upstream (reading free text into facts) and downstream (wording), never the verdict.
"""
from __future__ import annotations

from datetime import date
from typing import Any

from .facts import is_wood_or_pellet, roof_family

ORDER = {"DECLINE": 0, "REQUEST_INFO": 1, "REFER": 2, "APPROVE": 3}

CORE_REQUIRED = {  # 9.3 - required for every application
    "occupancy": "Occupancy (who lives in the home)",
    "roof.material": "Roof material",
    "roof.age_years": "Roof age (year the roof was installed)",
    "heating.primary": "Primary heat source",
    "electrical.panel_type": "Electrical panel type (circuit breaker or fuse)",
    "electrical.amps": "Electrical service amperage",
    "coverage_a": "Requested Coverage A (dwelling) amount",
}


def money(v: float | None) -> str:
    return "n/a" if v is None else f"${v:,.0f}"


def _f(section, outcome, reason, facts_used=(), missing=(), **data) -> dict:
    return {"section": section, "outcome": outcome, "reason": reason, "facts_used": list(facts_used),
            "missing": list(missing), **({"data": data} if data else {})}


def count_claims(claims: list[dict], submitted: date) -> dict:
    lookback = submitted.replace(year=submitted.year - 5)
    counted, excluded = [], []
    for c in claims:
        try:
            dol = date.fromisoformat(c["date_of_loss"])
        except Exception:
            excluded.append({**c, "excluded_because": "unparseable date_of_loss"})
            continue
        if not (lookback <= dol <= submitted):
            excluded.append({**c, "excluded_because": f"outside 5-year lookback ({lookback} to {submitted})"})
        elif c.get("status") not in ("paid", "open"):
            excluded.append({**c, "excluded_because": f"status '{c.get('status')}' does not count"})
        else:
            counted.append(c)
    return {"counted": counted, "excluded": excluded, "lookback_start": str(lookback)}


def match_disclosures(counted: list[dict], disclosed: list[dict]) -> list[dict]:
    """Return counted claims with no matching disclosure (same loss type and year)."""
    pool = [dict(d) for d in (disclosed or [])]
    undisclosed = []
    for c in counted:
        yr = c["date_of_loss"][:4]
        hit = next((d for d in pool if str(d.get("type", "")).lower() == str(c.get("type", "")).lower()
                    and str(d.get("year")) == yr), None)
        if hit:
            pool.remove(hit)
        else:
            undisclosed.append(c)
    return undisclosed


def evaluate(V: dict[str, Any], ctx: dict) -> list[dict]:
    """V: fact values. ctx: submitted_date, claims (status/data), disclosed, inspection_on_file."""
    F: list[dict] = []
    submitted = date.fromisoformat(ctx["submitted_date"])

    # ---- 9.3 core required items
    for fact, label in CORE_REQUIRED.items():
        if V.get(fact) is None:
            F.append(_f("9.3", "REQUEST_INFO", f"{label} is missing from the application and from all other sources.",
                        [fact], [label]))

    # ---- 1. Eligibility
    occ, mu = V.get("occupancy"), V.get("months_unoccupied")
    if occ in ("tenant", "vacant"):
        F.append(_f("1.1", "DECLINE", f"The home is {'tenant-occupied' if occ == 'tenant' else 'vacant'}; we only insure "
                    "owner-occupied homes (primary or secondary residence).", ["occupancy"]))
    elif mu is not None and mu > 2:
        F.append(_f("1.1", "DECLINE", f"The home has been unoccupied for about {mu:g} months; the limit is 60 consecutive days.",
                    ["months_unoccupied"]))
    if (n := V.get("str_nights_per_year")) is not None and n > 30:
        F.append(_f("1.2", "DECLINE", f"The home is rented short-term for about {n:g} nights a year; the limit is 30.",
                    ["str_nights_per_year"]))
    if V.get("existing_damage") is True:
        F.append(_f("1.3", "DECLINE", "The home has unrepaired damage (such as an active roof leak). It must be repaired "
                    "before we can offer coverage.", ["existing_damage"]))
    if V.get("electrical.knob_and_tube") is True:
        F.append(_f("1.4", "DECLINE", "Active knob-and-tube wiring is present in the home.", ["electrical.knob_and_tube"]))
    if V.get("electrical.panel_type") == "fuse":
        F.append(_f("1.4", "DECLINE", "The home has a fuse-type electrical panel.", ["electrical.panel_type"]))
    if (a := V.get("electrical.amps")) is not None and a < 100:
        F.append(_f("1.4", "DECLINE", f"Electrical service is {a:g} amps; the minimum is 100 amps.", ["electrical.amps"]))
    if V.get("oil_tank.present") is True:
        loc, age = V.get("oil_tank.location"), V.get("oil_tank.age_years")
        if loc is None:
            F.append(_f("1.5", "REQUEST_INFO", "An oil tank is present but its location is not stated.",
                        ["oil_tank.location"], ["Oil tank location (underground, basement or above-ground) and age"]))
        elif loc == "underground" and (age is None or age > 20):
            why = "of unknown age" if age is None else f"{age:g} years old"
            F.append(_f("1.5", "DECLINE", f"There is an underground heating-oil tank {why}; underground tanks must be 20 "
                        "years old or newer.", ["oil_tank.location", "oil_tank.age_years"]))
    if (cov := V.get("coverage_a")) is not None and cov > 1_500_000:
        F.append(_f("1.6", "DECLINE", f"Coverage A of {money(cov)} is above our $1,500,000 program limit; this home "
                    "should be placed in the High-Value program.", ["coverage_a"]))

    # ---- 2. Roof
    mat, age, cond = V.get("roof.material"), V.get("roof.age_years"), V.get("roof.condition")
    fam = roof_family(mat)
    if cond == "poor":
        F.append(_f("2.4", "DECLINE", "The inspection rates the roof condition as poor.", ["roof.condition"]))
    if fam is not None and age is not None:
        if fam == "asphalt":
            if age > 20:
                F.append(_f("2.3", "DECLINE", f"The asphalt shingle roof is {age:g} years old; the maximum is 20 years.",
                            ["roof.material", "roof.age_years"]))
            elif age > 15:
                if cond in ("good", "fair"):
                    pass  # 2.2 satisfied
                elif cond is None:
                    F.append(_f("2.2", "REQUEST_INFO", f"The asphalt shingle roof is {age:g} years old. Roofs 16-20 years "
                                "old need an inspection rating the roof good or fair, and none is on file.",
                                ["roof.material", "roof.age_years", "roof.condition"],
                                ["Roof inspection report with a roof condition rating"]))
        elif fam == "long_life":
            if age > 40:
                F.append(_f("2.5", "DECLINE", f"The {mat.replace('_', ' ')} roof is {age:g} years old; the maximum is 40 years.",
                            ["roof.material", "roof.age_years"]))
        else:
            F.append(_f("2", "REFER", f"Roof material '{mat}' is not addressed by the roof guidelines; an underwriter "
                        "must assess it.", ["roof.material"], gap=True))

    # ---- 3. Prior losses
    claims = ctx.get("claims") or {}
    if claims.get("status") == "unavailable":
        F.append(_f("9.3", "REQUEST_INFO", "The prior-claims (CLUE) report could not be retrieved, so the prior-loss rules "
                    "(3.1-3.4) could not be checked.", ["claims"],
                    ["Prior-claims (CLUE) report - service unavailable; resubmit to retry"], service_unavailable="claims"))
    else:
        rep = claims.get("data") or {"claims": []}
        cc = count_claims(rep.get("claims", []), submitted)
        counted = cc["counted"]
        water = [c for c in counted if str(c.get("type", "")).lower() == "water"]
        big = [c for c in counted if (c.get("amount") or 0) >= 50_000]
        desc = "; ".join(f"{c['type']} {c['date_of_loss']} {money(c.get('amount'))} ({c['status']})" for c in counted)
        if len(counted) >= 3:
            F.append(_f("3.1", "DECLINE", f"The claims history shows {len(counted)} paid or open claims in the last 5 years "
                        f"({desc}); the maximum is two.", ["claims"], counted=counted))
        elif len(water) >= 2:
            F.append(_f("3.2", "REFER", f"There are {len(water)} water-damage claims in the last 5 years; this needs an "
                        "underwriter's review.", ["claims"], counted=water))
        for c in big:
            F.append(_f("3.3", "REFER", f"A {c['type']} claim from {c['date_of_loss']} of {money(c.get('amount'))} is "
                        "$50,000 or more; this needs an underwriter's review.", ["claims"], claim=c))
        und = match_disclosures(counted, ctx.get("disclosed") or [])
        if und:
            d2 = "; ".join(f"{c['type']} loss on {c['date_of_loss']} ({money(c.get('amount'))})" for c in und)
            F.append(_f("3.4", "REFER", f"The claims history shows {d2} that was not disclosed on the application; this "
                        "is referred for misrepresentation review.", ["claims"], undisclosed=und))

    # ---- 4. Liability
    if V.get("pool.present") is True:
        h, gate = V.get("pool.fence_height_ft"), V.get("pool.self_latching_gate")
        bad = []
        if h is not None and h < 4:
            bad.append(f"the fence is {h:g} ft (minimum 4 ft)")
        if gate is False:
            bad.append("the gate is not self-latching")
        if bad:
            F.append(_f("4.1", "DECLINE", "The pool does not meet our fencing requirement: " + " and ".join(bad) + ".",
                        ["pool.fence_height_ft", "pool.self_latching_gate"]))
        elif h is None or gate is None:
            miss = []
            if h is None:
                miss.append("Pool fence height")
            if gate is None:
                miss.append("Whether the pool gate is self-latching")
            F.append(_f("4.1", "REQUEST_INFO", "A pool is present but the fence/gate details needed to check our 4 ft fence "
                        "and self-latching gate requirement are missing.",
                        ["pool.fence_height_ft", "pool.self_latching_gate"], miss))
        dv = V.get("pool.diving_board_or_slide")
        if dv is True:
            F.append(_f("4.2", "REFER", "The pool has a diving board or slide; this needs an underwriter's review.",
                        ["pool.diving_board_or_slide"]))
        elif dv is None:
            F.append(_f("4.2", "REQUEST_INFO", "A pool is present but it is not stated whether it has a diving board or slide.",
                        ["pool.diving_board_or_slide"], ["Whether the pool has a diving board or slide"]))
    if V.get("trampoline.present") is True:
        net = V.get("trampoline.safety_net")
        if net is False:
            F.append(_f("4.3", "DECLINE", "There is a trampoline without a safety net enclosure.",
                        ["trampoline.present", "trampoline.safety_net"]))
        elif net is None:
            F.append(_f("4.3", "REQUEST_INFO", "There is a trampoline but it is not stated whether it has a safety net enclosure.",
                        ["trampoline.safety_net"], ["Whether the trampoline has a safety net enclosure"]))
    if V.get("dogs.bite_history") is True:
        F.append(_f("4.4", "DECLINE", "A dog on the premises has a bite history.", ["dogs.bite_history"]))
    elif V.get("dogs.present") is True and V.get("dogs.bite_history") is None:
        F.append(_f("4.4", "REQUEST_INFO", "A dog is on the premises but its bite history is not stated.",
                    ["dogs.bite_history"], ["Bite history for each dog on the premises"]))

    # ---- 5. Heating
    if is_wood_or_pellet(V.get("heating.primary")):
        F.append(_f("5.1", "REFER", "The primary heat source is a wood or pellet stove; this needs an underwriter's review.",
                    ["heating.primary"]))
    if V.get("wood_stove.present") is True:
        pi, ul = V.get("wood_stove.professionally_installed"), V.get("wood_stove.ul_listed")
        bad = [t for t, v in (("not professionally installed", pi), ("not UL-listed", ul)) if v is False]
        if bad:
            F.append(_f("5.2", "DECLINE", "The supplemental wood/pellet stove is " + " and ".join(bad) + ".",
                        ["wood_stove.professionally_installed", "wood_stove.ul_listed"]))
        elif pi is None or ul is None:
            miss = [t for t, v in (("Whether the stove was professionally installed", pi), ("Whether the stove is UL-listed", ul))
                    if v is None]
            F.append(_f("5.2", "REQUEST_INFO", "A supplemental wood/pellet stove is present but its installation or "
                        "UL listing is not confirmed.", ["wood_stove.professionally_installed", "wood_stove.ul_listed"], miss))

    # ---- 6. Coastal / CAT
    dist = V.get("coast_distance_ft")
    if dist is None:
        F.append(_f("9.3", "REQUEST_INFO", "Distance to the coast could not be obtained from the property data service, so "
                    "the coastal rules (6.1, 6.2) could not be checked.", ["coast_distance_ft"],
                    ["Distance to coast (property data unavailable)"]))
    elif dist <= 1000:
        F.append(_f("6.1", "REFER", f"The home is about {dist:,.0f} ft from the coast (within 1,000 ft); this needs an "
                    "underwriter's review.", ["coast_distance_ft"]))
    elif dist <= 5280 and cov is not None and cov > 750_000:
        F.append(_f("6.2", "REFER", f"The home is about {dist:,.0f} ft from the coast (within 1 mile) and Coverage A of "
                    f"{money(cov)} is over $750,000; this needs an underwriter's review.", ["coast_distance_ft", "coverage_a"]))
    fz = V.get("flood_zone")
    if fz and str(fz).upper()[0] in ("A", "V"):
        F.append(_f("6.3", "NOTE", f"The home is in FEMA flood zone {fz}. Flood is excluded from this policy; the agent "
                    "should discuss separate flood coverage. This does not affect the decision.", ["flood_zone"]))

    # ---- 7. Authority & valuation
    if cov is not None and 800_000 < cov <= 1_500_000:
        F.append(_f("7.1", "REFER", f"Coverage A of {money(cov)} is above $800,000 and requires underwriter sign-off.",
                    ["coverage_a"]))
    rc = V.get("replacement_cost")
    if cov is not None:
        if rc is None:
            F.append(_f("9.3", "REQUEST_INFO", "The replacement cost estimate could not be obtained, so insurance-to-value "
                        "(7.2) could not be checked.", ["replacement_cost"], ["Replacement cost estimate (property data unavailable)"]))
        else:
            ratio = cov / rc
            if not (0.85 <= ratio <= 1.15):
                F.append(_f("7.2", "REQUEST_INFO", f"Coverage A of {money(cov)} is {ratio:.0%} of the {money(rc)} replacement "
                            "cost estimate; it must be between 85% and 115%. Please confirm or adjust Coverage A.",
                            ["coverage_a", "replacement_cost"],
                            [f"Confirm or adjust Coverage A to between {money(0.85 * rc)} and {money(1.15 * rc)} "
                             f"(85-115% of the {money(rc)} replacement cost estimate)"], ratio=round(ratio, 3)))
    return F


def decide(findings: list[dict]) -> str:
    outs = {f["outcome"] for f in findings}
    for d in ("DECLINE", "REQUEST_INFO", "REFER"):
        if d in outs:
            return d
    return "APPROVE"


def run_rules(facts: dict[str, dict], ctx: dict, concerns: list[dict] | None = None) -> dict:
    """Evaluate, then apply 9.2 (unresolvable application-vs-notes conflicts) by counterfactual re-evaluation."""
    V = {k: f["value"] for k, f in facts.items()}
    base = evaluate(V, ctx)
    base_decision = decide(base)

    conflicts_92 = []
    for k, f in facts.items():
        if f["source"] != "application":
            continue
        notes_vals = [c for c in f["candidates"] if c["source"] == "agent_notes" and c["value"] is not None
                      and c["value"] != f["value"]]
        for nc in notes_vals:
            alt_findings = evaluate({**V, k: nc["value"]}, ctx)
            alt_decision = decide(alt_findings)
            if alt_decision != base_decision:
                conflicts_92.append({"fact": k, "application": f["value"], "agent_notes": nc["value"], "quote": nc.get("quote"),
                                     "decision_if_application": base_decision, "decision_if_notes": alt_decision})
                break

    findings = base
    if conflicts_92:
        conflicted = {c["fact"] for c in conflicts_92}
        findings = [x for x in base if not (set(x["facts_used"]) & conflicted)]
        for c in conflicts_92:
            findings.append(_f("9.2", "REQUEST_INFO",
                               f"The application and the agent's notes disagree on {c['fact'].replace('_', ' ').replace('.', ' ')} "
                               f"(application: {c['application']}, notes: {c['agent_notes']}), there is no inspection or "
                               "third-party data to settle it, and the answer changes the decision.",
                               [c["fact"]], [f"Confirm {c['fact'].replace('_', ' ').replace('.', ' ')}: application says "
                                             f"{c['application']}, agent notes say {c['agent_notes']}"], conflict=c))

    for cn in concerns or []:
        rel = cn.get("related_fact")
        if rel and rel in facts and facts[rel]["source"] in ("inspection", "third_party"):
            continue  # a more authoritative source already settles it
        sec = cn.get("section") or "9.2"
        findings.append(_f("9.2", "REQUEST_INFO", f"The agent's notes raise an unresolved point: {cn['description']}",
                           [rel] if rel else [], [f"Clarify: {cn['description']}"], concern=cn, related_section=sec))

    decision = decide(findings)
    return {"findings": findings, "decision": decision, "conflicts_9_2": conflicts_92, "base_decision": base_decision}
