"""Client for the (mock) enterprise services, with authentication, timeouts and retries.

Retry policy: transient failures (HTTP 5xx, timeouts, connection errors) are retried with
exponential backoff + jitter. 404 is a definitive answer ("nothing on file"), not a failure.
401/403 are configuration errors and are raised immediately.
Every call, including each retry, is written to the run trace.
"""
from __future__ import annotations

import random
import time
from dataclasses import dataclass, field
from typing import Any

import httpx

from .config import get_settings
from .tracing import TraceLogger


@dataclass
class ServiceResult:
    service: str
    status: str  # ok | not_found | unavailable
    data: Any = None
    http_status: int | None = None
    attempts: int = 0
    latency_ms: float = 0.0
    error: str | None = None
    attempt_log: list[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "service": self.service,
            "status": self.status,
            "data": self.data,
            "http_status": self.http_status,
            "attempts": self.attempts,
            "latency_ms": round(self.latency_ms, 1),
            "error": self.error,
        }


class ServiceAuthError(RuntimeError):
    pass


SERVICE_PATHS = {
    "property": lambda a: (f"/property/{a['property_id']}", None),
    "claims": lambda a: ("/claims", {"property_id": a["property_id"], "applicant_id": a.get("applicant_id")}),
    "cat_risk": lambda a: (f"/cat-risk/{a['property_id']}", None),
    "inspection": lambda a: (f"/inspections/{a['property_id']}", None),
}


CLIENT_FACTORY = None  # tests can inject e.g. a FastAPI TestClient bound to the mock server


class ServicesClient:
    def __init__(self, tracer: TraceLogger | None = None, client: httpx.Client | None = None):
        s = get_settings()
        self.s = s
        self.tracer = tracer
        if client is None and CLIENT_FACTORY is not None:
            client = CLIENT_FACTORY()
        self._client = client or httpx.Client(
            base_url=s.services_base_url,
            headers={"Authorization": f"Bearer {s.services_api_key}"},
            timeout=s.service_timeout_s,
        )

    def call(self, service: str, args: dict, node: str = "tools", requested_by: str = "llm") -> ServiceResult:
        path, params = SERVICE_PATHS[service](args)
        if params:
            params = {k: v for k, v in params.items() if v is not None}
        res = ServiceResult(service=service, status="unavailable")
        t_start = time.perf_counter()
        for attempt in range(1, self.s.service_max_attempts + 1):
            res.attempts = attempt
            t0 = time.perf_counter()
            try:
                r = self._client.get(path, params=params)
                code = r.status_code
                err = None
            except httpx.HTTPError as e:  # timeout / connection error
                code, err, r = None, f"{type(e).__name__}: {e}", None
            dt = (time.perf_counter() - t0) * 1000
            res.attempt_log.append({"attempt": attempt, "http_status": code, "ms": round(dt, 1), "error": err})
            if code in (401, 403):
                raise ServiceAuthError(f"{service}: HTTP {code} - check SERVICES_API_KEY")
            if code == 200:
                res.status, res.data, res.http_status = "ok", r.json(), 200
                break
            if code == 404:
                detail = None
                try:
                    detail = r.json().get("detail")
                except Exception:
                    pass
                res.status, res.http_status, res.error = "not_found", 404, detail or "not found"
                break
            # transient: 5xx / 429 / network
            res.http_status, res.error = code, err or (r.text[:200] if r is not None else None)
            if attempt < self.s.service_max_attempts:
                backoff = self.s.service_backoff_base_s * (2 ** (attempt - 1))
                time.sleep(backoff + random.uniform(0, backoff / 2))
        res.latency_ms = (time.perf_counter() - t_start) * 1000
        if self.tracer:
            self.tracer.log(
                "tool_call",
                node=node,
                tool=service,
                requested_by=requested_by,
                args=args,
                path=path,
                status=res.status,
                http_status=res.http_status,
                attempts=res.attempts,
                attempt_log=res.attempt_log,
                latency_ms=round(res.latency_ms, 1),
                response=res.data if res.status == "ok" else res.error,
            )
        return res
