"""The underwriting agent as a LangGraph state graph.

    intake -> screen -> investigate <-> tools -> coverage_guard -> extract -> reconcile
           -> evaluate -> decide -> explain -> [human_review if REFER & HITL] -> finalize

Design principle: "the LLM reads and writes, code decides".
  * investigate  - LLM tool-calling loop chooses and calls the enterprise services
  * coverage_guard - deterministic check that every required service was consulted (defence in depth)
  * extract      - LLM turns free text (agent notes, inspection report) into grounded, quoted facts
  * reconcile / evaluate / decide - deterministic source hierarchy (9.1-9.3) and rules (0.1 precedence)
  * explain      - LLM rewrites the reasons in plain language, validated against the rule output
With LLM_PROVIDER=none the same graph runs with deterministic stand-ins for the three LLM nodes.
"""
from __future__ import annotations

import functools
import json
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Annotated, Any, Optional, TypedDict

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.tools import tool
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.types import interrupt
from pydantic import BaseModel, Field

from . import facts as F
from .config import get_settings
from .guidelines import get_guidelines
from .llm import get_chat_model, logged_invoke, structured
from .rules import run_rules
from .screening import find_injections, find_non_permitted, mentions_non_permitted
from .services import ServicesClient
from .text_facts import (EXTRACT_SYSTEM, NON_PERMITTED_CATEGORIES, TextAnalysis, fact_catalog, ground, regex_extract,
                         validate_flags, validate_values)
from .tracing import get_tracer

REQUIRED_SERVICES = ("property", "claims", "cat_risk", "inspection")


def _merge(a: dict | None, b: dict | None) -> dict:
    return {**(a or {}), **(b or {})}


class UWState(TypedDict, total=False):
    trace_id: str
    case: dict
    hitl: bool
    mode: str
    messages: Annotated[list, add_messages]
    tool_rounds: int
    evidence: Annotated[dict, _merge]
    screening_flags: list
    text_analysis: dict
    facts: dict
    disagreements: list
    rule_result: dict
    decision: str
    reasons: list
    missing_info: list
    flags: list
    flag_details: list
    other_findings: list
    notes_for_agent: list
    review: Optional[dict]
    response: dict


# ------------------------------------------------------------------ tools exposed to the LLM
@tool
def get_property_data(property_id: str) -> dict:
    """Third-party property data: year built, size, roof installation year (from building permits, may be null),
    replacement cost estimate and distance to coast. Needed for roof age (section 2), coastal rules (6.1/6.2)
    and insurance-to-value (7.2)."""
    raise NotImplementedError  # executed by the `tools` node


@tool
def get_claims_history(property_id: str, applicant_id: str) -> dict:
    """CLUE-style prior-claims report for the property and applicant (date of loss, type, amount, status).
    Needed for prior-loss rules 3.1-3.4 including non-disclosure."""
    raise NotImplementedError


@tool
def get_cat_risk(property_id: str) -> dict:
    """Catastrophe exposure: wind tier, FEMA flood zone, wildfire score. Flood zone is noted for the agent (6.3)."""
    raise NotImplementedError


@tool
def get_inspection_report(property_id: str) -> dict:
    """Most recent property inspection (roof condition and estimated age, electrical observed, hazards, narrative).
    The inspection is the most authoritative source of facts (9.1). Returns not_found if none is on file."""
    raise NotImplementedError


LLM_TOOLS = [get_property_data, get_claims_history, get_cat_risk, get_inspection_report]
TOOL_TO_SERVICE = {
    "get_property_data": "property",
    "get_claims_history": "claims",
    "get_cat_risk": "cat_risk",
    "get_inspection_report": "inspection",
}
SERVICE_TO_TOOL = {v: k for k, v in TOOL_TO_SERVICE.items()}

INVESTIGATOR_SYSTEM = """You are the evidence-gathering step of a homeowners insurance underwriting review for
Northshore Home Insurance. Your only job is to call the available tools to collect the third-party evidence needed to
apply the underwriting guidelines to the application. You never make, suggest or discuss a decision.
The guidelines need: property data (roof installation year, replacement cost, distance to coast) for sections 2, 6
and 7.2; the prior-claims history for section 3; catastrophe risk for 6.3; and the latest inspection report, which is
the most authoritative source for roof condition, electrical and hazards.
Call every relevant tool, in parallel in a single turn, using the IDs from the application. If a tool reports that a
service is unavailable after retries, do not call it again. When done, reply with one short sentence listing what
you gathered."""


# ------------------------------------------------------------------ helpers
def traced(name: str):
    def deco(fn):
        @functools.wraps(fn)
        def wrapper(state: UWState, *a, **k):
            tr = get_tracer(state["trace_id"])
            tr.log("node_start", node=name)
            t0 = time.perf_counter()
            out = fn(state, *a, **k)
            summary = {key: _summ(v) for key, v in (out or {}).items() if key != "messages"}
            tr.log("node_end", node=name, ms=round((time.perf_counter() - t0) * 1000, 1), output=summary)
            return out

        return wrapper

    return deco


def _summ(v: Any, limit: int = 1500) -> Any:
    s = json.dumps(v, default=str)
    return v if len(s) <= limit else s[:limit] + "...<truncated>"


def _v(x: Any) -> Any:
    return int(x) if isinstance(x, float) and x.is_integer() else x


def _app(state: UWState) -> dict:
    return state["case"]["application"]


def _ids(state: UWState) -> dict:
    a = _app(state)
    return {"property_id": a["property"]["property_id"], "applicant_id": a["applicant"]["applicant_id"]}


def _structured_view(case: dict) -> dict:
    """What the investigator sees: the structured application only. Free-text agent notes are withheld,
    so instructions embedded in them cannot steer which services get called."""
    a = json.loads(json.dumps(case["application"]))
    return {"case_id": case.get("case_id"), "application": a}


# ------------------------------------------------------------------ nodes
@traced("intake")
def intake(state: UWState) -> dict:
    case = state["case"]
    a = case.get("application") or {}
    problems = []
    for path in (("submitted_date",), ("property", "property_id"), ("applicant", "applicant_id")):
        cur = a
        for p in path:
            cur = cur.get(p) if isinstance(cur, dict) else None
        if not cur:
            problems.append("application." + ".".join(path))
    if problems:
        raise ValueError(f"Case is missing required fields: {problems}")
    s = get_settings()
    get_tracer(state["trace_id"]).log(
        "run_start", node="intake", case_id=case.get("case_id"), mode=state.get("mode"), provider=s.llm_provider,
        model=s.llm_model, guidelines_version=get_guidelines().version, hitl=state.get("hitl", False), case=case)
    view = _structured_view(case)
    return {
        "messages": [SystemMessage(INVESTIGATOR_SYSTEM),
                     HumanMessage("Gather the evidence for this referred application:\n" + json.dumps(view, indent=2))],
        "tool_rounds": 0,
        "evidence": {},
    }


@traced("screen")
def screen(state: UWState) -> dict:
    notes = state["case"].get("agent_notes") or ""
    flags = [{**f, "source": "agent_notes"} for f in find_injections(notes) + find_non_permitted(notes)]
    return {"screening_flags": flags}


@traced("investigate")
def investigate(state: UWState) -> dict:
    tr = get_tracer(state["trace_id"])
    rounds = state.get("tool_rounds", 0)
    called = set((state.get("evidence") or {}).keys())
    llm = get_chat_model() if state.get("mode") == "llm" else None
    if llm is not None:
        try:
            msg = logged_invoke(llm.bind_tools(LLM_TOOLS), state["messages"], tr, "investigate", "choose_tools")
            return {"messages": [msg], "tool_rounds": rounds + 1}
        except Exception as e:
            tr.log("fallback", node="investigate", reason=f"LLM tool selection failed: {e}; using deterministic plan")
    # deterministic planner: call everything not yet called, then stop
    todo = [s for s in REQUIRED_SERVICES if s not in called]
    ids = _ids(state)
    if not todo:
        return {"messages": [AIMessage("Evidence gathered from: " + ", ".join(sorted(called)))], "tool_rounds": rounds + 1}
    calls = []
    for svc in todo:
        args = {"property_id": ids["property_id"]}
        if svc == "claims":
            args["applicant_id"] = ids["applicant_id"]
        calls.append({"name": SERVICE_TO_TOOL[svc], "args": args, "id": f"det_{svc}_{rounds}", "type": "tool_call"})
    return {"messages": [AIMessage(content="", tool_calls=calls)], "tool_rounds": rounds + 1}


def route_after_investigate(state: UWState) -> str:
    last = state["messages"][-1]
    if getattr(last, "tool_calls", None) and state.get("tool_rounds", 0) <= get_settings().llm_max_tool_rounds:
        return "tools"
    return "coverage_guard"


@traced("tools")
def tools(state: UWState) -> dict:
    tr = get_tracer(state["trace_id"])
    ids = _ids(state)
    client = ServicesClient(tracer=tr)
    calls = state["messages"][-1].tool_calls

    def run(call):
        name = call["name"]
        svc = TOOL_TO_SERVICE.get(name)
        if svc is None:
            return call, None, {"status": "error", "error": f"unknown tool {name}"}
        args = dict(call.get("args") or {})
        # argument guard: the tool may only query the subject of this application
        fixed = {k: v for k, v in ids.items() if k in args or (k == "applicant_id" and svc == "claims")}
        if any(args.get(k) != v for k, v in fixed.items()):
            tr.log("guard", node="tools", kind="tool_args_corrected", tool=name, requested=args, used={**args, **fixed})
        args.update(fixed)
        return call, svc, client.call(svc, args, node="tools", requested_by="llm" if state.get("mode") == "llm" else "planner").to_dict()

    with ThreadPoolExecutor(max_workers=4) as ex:
        results = list(ex.map(run, calls))
    msgs, evidence = [], {}
    for call, svc, res in results:
        if svc:
            evidence[svc] = res
        msgs.append(ToolMessage(content=json.dumps({"status": res["status"], "data": res.get("data"), "error": res.get("error")},
                                                   default=str), tool_call_id=call["id"], name=call["name"]))
    return {"messages": msgs, "evidence": evidence}


@traced("coverage_guard")
def coverage_guard(state: UWState) -> dict:
    """Every required service must have been consulted, whatever the LLM chose (e.g. it was told to skip one)."""
    tr = get_tracer(state["trace_id"])
    have = state.get("evidence") or {}
    missing = [s for s in REQUIRED_SERVICES if s not in have]
    if not missing:
        tr.log("guard", node="coverage_guard", kind="coverage_ok", services=sorted(have))
        return {}
    tr.log("guard", node="coverage_guard", kind="forced_tool_calls", missing=missing,
           note="LLM did not call these required services; calling them directly")
    ids = _ids(state)
    client = ServicesClient(tracer=tr)

    def run(svc):
        args = {"property_id": ids["property_id"]}
        if svc == "claims":
            args["applicant_id"] = ids["applicant_id"]
        return svc, client.call(svc, args, node="coverage_guard", requested_by="guard").to_dict()

    with ThreadPoolExecutor(max_workers=4) as ex:
        ev = dict(ex.map(run, missing))
    return {"evidence": ev}


def _inspection_text(evidence: dict) -> str:
    ins = evidence.get("inspection") or {}
    if ins.get("status") != "ok":
        return ""
    d = ins["data"]
    parts = []
    if d.get("electrical_observed"):
        parts.append(f"Electrical observed: {d['electrical_observed']}.")
    if d.get("hazards_observed"):
        parts.append("Hazards observed: " + "; ".join(d["hazards_observed"]) + ".")
    if d.get("narrative"):
        parts.append(f"Narrative: {d['narrative']}")
    return "\n".join(parts)


@traced("extract")
def extract(state: UWState) -> dict:
    tr = get_tracer(state["trace_id"])
    app = _app(state)
    year = int(app["submitted_date"][:4])
    docs = {"agent_notes": state["case"].get("agent_notes") or "", "inspection": _inspection_text(state.get("evidence") or {})}
    llm = get_chat_model() if state.get("mode") == "llm" else None
    out = {"facts": [], "concerns": [], "flags": [], "dropped": [], "extractor": "llm" if llm else "regex"}
    for source, text in docs.items():
        if not text.strip():
            continue
        items, concerns, flags = None, [], []
        if llm is not None:
            try:
                runnable = structured(llm, TextAnalysis)
                msgs = [SystemMessage(EXTRACT_SYSTEM.format(catalog=fact_catalog(), year=year,
                                                            categories=", ".join(NON_PERMITTED_CATEGORIES))),
                        HumanMessage(f"Application submitted {app['submitted_date']}. Document source: {source}.\n"
                                     f"<document>\n{text}\n</document>")]
                res = logged_invoke(runnable, msgs, tr, "extract", f"extract_facts:{source}")
                parsed: TextAnalysis | None = res.get("parsed")
                if parsed is None:
                    raise ValueError(f"unparseable structured output: {res.get('parsing_error')}")
                items = [{**f.model_dump(), "source": source, "extractor": "llm"} for f in parsed.facts]
                concerns = [{**c.model_dump(), "source": source} for c in parsed.concerns]
                flags = [{**g.model_dump(), "source": source, "detector": "llm"} for g in parsed.flags]
            except Exception as e:
                tr.log("fallback", node="extract", source=source, reason=f"LLM extraction failed: {e}; using regex")
                items = None
        if items is None:
            items = regex_extract(text, source, year)
        kept, dropped = ground(items, text)
        kept, invalid = validate_values(kept)
        gc, dc = ground(concerns, text)
        gf, df = ground(flags, text)
        gf, bad_flags = validate_flags(gf)
        df += bad_flags
        for d in dropped + dc + df:
            d.setdefault("drop_reason", "quote not found verbatim in source (ungrounded)")
        if dropped or invalid or dc or df:
            tr.log("guard", node="extract", kind="dropped_extractions", source=source, dropped=dropped + invalid + dc + df)
        out["facts"] += kept
        out["concerns"] += gc
        out["flags"] += gf
        out["dropped"] += dropped + invalid + dc + df
        if source == "inspection":  # 10.1 applies to inspection reports too
            out["flags"] += [{**f, "source": source} for f in find_injections(text) + find_non_permitted(text)]
    return {"text_analysis": out}


@traced("reconcile")
def reconcile(state: UWState) -> dict:
    app = _app(state)
    ev = state.get("evidence") or {}
    cands = F.application_candidates(app) + F.service_candidates(app, ev)
    for t in (state.get("text_analysis") or {}).get("facts", []):
        src = t["source"]
        label = "agent notes" if src == "agent_notes" else "inspection report text"
        cands.append(F._cand(t["fact"], t["value"], src, f"{label} ({t.get('extractor')}): \"{t['quote']}\"", t["quote"]))
    facts = F.reconcile(cands)
    return {"facts": facts, "disagreements": F.disagreements(facts)}


@traced("evaluate")
def evaluate(state: UWState) -> dict:
    app = _app(state)
    ev = state.get("evidence") or {}
    claims = ev.get("claims") or {"status": "unavailable"}
    if claims.get("status") == "not_found":
        claims = {"status": "ok", "data": {"claims": []}, "note": "no CLUE report on file (treated as no prior claims)"}
    ctx = {"submitted_date": app["submitted_date"], "claims": claims, "disclosed": app.get("prior_claims_disclosed") or []}
    concerns = [c for c in (state.get("text_analysis") or {}).get("concerns", []) if c.get("source") == "agent_notes"]
    return {"rule_result": run_rules(state["facts"], ctx, concerns)}


@traced("decide")
def decide(state: UWState) -> dict:
    g = get_guidelines()
    rr = state["rule_result"]
    decision = rr["decision"]
    findings = rr["findings"]
    driving = [f for f in findings if f["outcome"] == decision] if decision != "APPROVE" else []
    by_sec: dict[str, list[str]] = {}
    for f in driving:
        by_sec.setdefault(f["section"], [])
        if f["reason"] not in by_sec[f["section"]]:
            by_sec[f["section"]].append(f["reason"])
    reasons = [{"guideline_id": s, "explanation": " ".join(r), "title": g.title(s)}
               for s, r in sorted(by_sec.items(), key=lambda kv: [int(x) for x in kv[0].split(".")])]
    missing = []
    if decision == "REQUEST_INFO":
        for f in driving:
            for m in f["missing"]:
                if m not in missing:
                    missing.append(m)
    other = [{"guideline_id": f["section"], "outcome": f["outcome"], "explanation": f["reason"]}
             for f in findings if f["outcome"] not in (decision, "NOTE")]
    notes = [f["reason"] for f in findings if f["outcome"] == "NOTE"]
    for d in state.get("disagreements") or []:
        if d["fact"] not in {c["fact"] for c in rr.get("conflicts_9_2", [])}:
            srcs = ", ".join(f"{c['source']}={_v(c['value'])}" for c in d["candidates"])
            notes.append(f"Sources disagreed on {d['fact']} ({srcs}); used the {d['chosen']['source']} value "
                         f"{_v(d['chosen']['value'])} per guideline 9.1.")

    # compliance flags
    all_flags = (state.get("screening_flags") or []) + (state.get("text_analysis") or {}).get("flags", [])
    flags, details = [], []
    if any(f["kind"] == "embedded_instruction" for f in all_flags):
        flags.append("EMBEDDED_INSTRUCTION")
    if any(f["kind"] == "non_permitted_factor" for f in all_flags):
        flags.append("NON_PERMITTED_FACTOR_DISREGARDED")
    seen = set()
    for f in all_flags:
        k = (f["kind"], f.get("category"), f["quote"])
        if k not in seen:
            seen.add(k)
            details.append({"flag": "EMBEDDED_INSTRUCTION" if f["kind"] == "embedded_instruction" else "NON_PERMITTED_FACTOR_DISREGARDED",
                            "category": f.get("category"), "source": f.get("source"), "quote": f["quote"],
                            "detector": f.get("detector"), "action": "ignored for the decision (8.2 / 10.1)"})
    # drop a quote that merely contains another, more specific quote of the same flag
    details = [d for d in details if not any(o is not d and o["flag"] == d["flag"] and o["quote"] in d["quote"]
                                             and o["quote"] != d["quote"] for o in details)]
    for svc, r in (state.get("evidence") or {}).items():
        if r.get("status") == "unavailable":
            flags.append(f"SERVICE_UNAVAILABLE:{svc.upper()}")
    if any(f.get("data", {}).get("gap") for f in findings):
        flags.append("GUIDELINE_GAP")
    for r in reasons:
        assert g.is_valid(r["guideline_id"]), f"invalid citation {r['guideline_id']}"
    return {"decision": decision, "reasons": reasons, "missing_info": missing, "flags": flags, "flag_details": details,
            "other_findings": other, "notes_for_agent": notes}


class _Expl(BaseModel):
    guideline_id: str
    explanation: str = Field(description="plain-language explanation, 1-2 sentences")


class _Expls(BaseModel):
    items: list[_Expl]


EXPLAIN_SYSTEM = """You write the explanation an insurance agent and applicant will read for an underwriting decision
that a rules engine has ALREADY made. For each item, rewrite the draft reason in plain, courteous language:
one or two sentences, keep every number and fact, do not add new reasons, do not change or soften the outcome, and do
not mention any personal characteristic of the applicant. Return exactly one item per guideline_id, using the same ids."""


@traced("explain")
def explain(state: UWState) -> dict:
    reasons = state.get("reasons") or []
    llm = get_chat_model() if state.get("mode") == "llm" else None
    if not reasons or llm is None:
        return {}
    tr = get_tracer(state["trace_id"])
    g = get_guidelines()
    payload = [{"guideline_id": r["guideline_id"], "guideline_text": g.snippet([r["guideline_id"]]), "draft_reason": r["explanation"]}
               for r in reasons]
    try:
        res = logged_invoke(structured(llm, _Expls),
                            [SystemMessage(EXPLAIN_SYSTEM),
                             HumanMessage(f"Decision: {state['decision']}\nItems:\n{json.dumps(payload, indent=2)}")],
                            tr, "explain", "plain_language_reasons")
        parsed = res.get("parsed")
        if parsed is None:
            raise ValueError("unparseable")
    except Exception as e:
        tr.log("fallback", node="explain", reason=f"LLM explanation failed: {e}; keeping rule text")
        return {}
    by_id = {i.guideline_id: i.explanation.strip() for i in parsed.items}
    new = []
    import re as _re

    for r in reasons:
        cand = by_id.get(r["guideline_id"])
        problems = []
        if not cand:
            problems.append("missing")
        else:
            if len(cand) > 700:
                problems.append("too long")
            nums = set(_re.findall(r"\d[\d,.]*\d|\d", r["explanation"]))
            lost = [n for n in nums if n not in cand]
            if lost:
                problems.append(f"dropped numbers {lost}")
            if mentions_non_permitted(cand):
                problems.append("mentions non-permitted factor")
        if problems:
            tr.log("guard", node="explain", kind="explanation_rejected", guideline_id=r["guideline_id"], problems=problems,
                   candidate=cand)
            new.append(r)
        else:
            new.append({**r, "explanation": cand, "draft": r["explanation"]})
    return {"reasons": new}


def route_after_explain(state: UWState) -> str:
    return "human_review" if state.get("hitl") and state.get("decision") == "REFER" else "finalize"


@traced("human_review")
def human_review(state: UWState) -> dict:
    tr = get_tracer(state["trace_id"])
    tr.log("hitl_pause", node="human_review", decision=state["decision"], reasons=state["reasons"])
    answer = interrupt({"trace_id": state["trace_id"], "case_id": state["case"]["case_id"],
                        "agent_recommendation": "REFER", "reasons": state["reasons"]})
    final = str(answer.get("decision", "")).upper()
    if final not in {"APPROVE", "DECLINE", "REQUEST_INFO"}:
        raise ValueError("Underwriter decision must be APPROVE, DECLINE or REQUEST_INFO")
    review = {"underwriter_id": answer.get("underwriter_id"), "decision": final, "comment": answer.get("comment"),
              "reasons": answer.get("reasons") or [], "missing_info": answer.get("missing_info") or [],
              "reviewed_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    tr.log("hitl_resume", node="human_review", review=review)
    upd: dict = {"review": review, "decision": final}
    if final == "APPROVE":
        upd["missing_info"] = []
    if review["reasons"]:
        upd["reasons"] = review["reasons"] + state["reasons"]
    if final == "REQUEST_INFO":
        upd["missing_info"] = review["missing_info"]
    return upd


def build_response(state: UWState, status: str = "COMPLETE") -> dict:
    resp = {
        "case_id": state["case"].get("case_id"),
        "decision": state["decision"],
        "reasons": [{"guideline_id": r["guideline_id"], "explanation": r["explanation"]} for r in state.get("reasons") or []],
        "missing_info": state.get("missing_info") or [],
        "flags": state.get("flags") or [],
        # extra fields (allowed by the contract)
        "trace_id": state["trace_id"],
        "status": status,
        "other_findings": state.get("other_findings") or [],
        "notes_for_agent": state.get("notes_for_agent") or [],
        "flag_details": state.get("flag_details") or [],
        "mode": state.get("mode"),
        "guidelines_version": get_guidelines().version,
    }
    if state.get("review"):
        resp["agent_recommendation"] = "REFER"
        resp["review"] = state["review"]
    return resp


@traced("finalize")
def finalize(state: UWState) -> dict:
    resp = build_response(state)
    get_tracer(state["trace_id"]).log("run_end", node="finalize", response=resp)
    return {"response": resp}


# ------------------------------------------------------------------ graph
def build_graph(checkpointer=None):
    g = StateGraph(UWState)
    for name, fn in [("intake", intake), ("screen", screen), ("investigate", investigate), ("tools", tools),
                     ("coverage_guard", coverage_guard), ("extract", extract), ("reconcile", reconcile),
                     ("evaluate", evaluate), ("decide", decide), ("explain", explain), ("human_review", human_review),
                     ("finalize", finalize)]:
        g.add_node(name, fn)
    g.add_edge(START, "intake")
    g.add_edge("intake", "screen")
    g.add_edge("screen", "investigate")
    g.add_conditional_edges("investigate", route_after_investigate, {"tools": "tools", "coverage_guard": "coverage_guard"})
    g.add_edge("tools", "investigate")
    g.add_edge("coverage_guard", "extract")
    g.add_edge("extract", "reconcile")
    g.add_edge("reconcile", "evaluate")
    g.add_edge("evaluate", "decide")
    g.add_edge("decide", "explain")
    g.add_conditional_edges("explain", route_after_explain, {"human_review": "human_review", "finalize": "finalize"})
    g.add_edge("human_review", "finalize")
    g.add_edge("finalize", END)
    return g.compile(checkpointer=checkpointer or InMemorySaver())


_GRAPH = None


def get_graph():
    global _GRAPH
    if _GRAPH is None:
        _GRAPH = build_graph()
    return _GRAPH
