"""FastAPI service exposing the underwriting agent.

Run:   uvicorn uw_agent.api:app --port 8000
Auth:  Authorization: Bearer <UW_API_KEY>   (default key: uw-demo-key)
Docs:  http://localhost:8000/docs
"""
from __future__ import annotations

import html
import json
from typing import Any, Literal, Optional

import httpx
from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, ConfigDict, Field

from .agent import pending_reviews, resume_case, run_case
from .config import get_settings
from .guidelines import get_guidelines
from .services import ServiceAuthError
from .tracing import read_trace

app = FastAPI(title="Northshore Underwriting Referral Agent", version="1.0",
              description="Reviews referred HO-3 applications against the Northshore guidelines v4.2.")


def auth(authorization: Optional[str] = Header(default=None), x_api_key: Optional[str] = Header(default=None)):
    key = get_settings().api_key
    if authorization == f"Bearer {key}" or x_api_key == key:
        return
    raise HTTPException(401, "Missing or invalid API key (use 'Authorization: Bearer <UW_API_KEY>')")


class CaseIn(BaseModel):
    model_config = ConfigDict(extra="allow")
    case_id: str
    application: dict
    agent_notes: str = ""


class Reason(BaseModel):
    guideline_id: str
    explanation: str


class UnderwriteResponse(BaseModel):
    model_config = ConfigDict(extra="allow")
    case_id: str
    decision: Literal["APPROVE", "DECLINE", "REFER", "REQUEST_INFO"]
    reasons: list[Reason]
    missing_info: list[str]
    flags: list[str]
    trace_id: str
    status: str = Field(description="COMPLETE, or PENDING_REVIEW when a REFER is paused for an underwriter")


class ReviewIn(BaseModel):
    decision: Literal["APPROVE", "DECLINE", "REQUEST_INFO"]
    underwriter_id: str
    comment: str = ""
    reasons: list[Reason] = []
    missing_info: list[str] = []


@app.get("/health")
def health() -> dict[str, Any]:
    s = get_settings()
    try:
        r = httpx.get(f"{s.services_base_url}/health", timeout=3)
        services = r.json()
    except Exception as e:
        services = {"status": "unreachable", "error": str(e)}
    return {"status": "ok", "llm_provider": s.llm_provider, "llm_model": s.llm_model,
            "guidelines_version": get_guidelines().version, "services": services, "hitl_default": s.hitl_default}


@app.post("/v1/underwrite", response_model=UnderwriteResponse, dependencies=[Depends(auth)])
def underwrite(case: CaseIn,
               hitl: Optional[bool] = Query(None, description="Pause REFER decisions for underwriter review"),
               mode: Optional[Literal["llm", "deterministic"]] = Query(None, description="Override the agent mode")):
    if mode == "llm" and not get_settings().llm_enabled:
        raise HTTPException(400, "mode=llm requested but no LLM provider is configured")
    try:
        return run_case(case.model_dump(), mode=mode, hitl=hitl)
    except ServiceAuthError as e:
        raise HTTPException(502, str(e))
    except ValueError as e:
        raise HTTPException(422, str(e))


@app.get("/v1/reviews", dependencies=[Depends(auth)])
def list_reviews():
    return pending_reviews()


@app.post("/v1/reviews/{trace_id}", response_model=UnderwriteResponse, dependencies=[Depends(auth)])
def submit_review(trace_id: str, review: ReviewIn):
    try:
        return resume_case(trace_id, review.model_dump())
    except KeyError:
        raise HTTPException(404, "No paused review with that trace_id")


@app.get("/v1/runs/{trace_id}", dependencies=[Depends(auth)])
def get_run(trace_id: str):
    try:
        return read_trace(trace_id)
    except FileNotFoundError:
        raise HTTPException(404, "Unknown trace_id")


@app.get("/v1/runs/{trace_id}/view", response_class=HTMLResponse)
def view_run(trace_id: str, key: str = Query(..., description="API key (so the page opens in a browser)")):
    """Readable timeline of one run, for walking through a decision."""
    if key != get_settings().api_key:
        raise HTTPException(401, "Invalid key")
    try:
        events = read_trace(trace_id)
    except FileNotFoundError:
        raise HTTPException(404, "Unknown trace_id")
    return render_trace_html(events)


def _headline(e: dict) -> str:
    ev = e["event"]
    if ev == "tool_call":
        tries = f", {e['attempts']} attempts" if e.get("attempts", 1) > 1 else ""
        return f"{e['tool']} -> {e['status']} (HTTP {e.get('http_status')}{tries}, {e.get('latency_ms')} ms, by {e.get('requested_by')})"
    if ev == "llm_call":
        u = e.get("usage") or {}
        return f"{e.get('purpose')} via {e.get('model')} ({e.get('latency_ms')} ms, {u.get('total_tokens', '?')} tokens)"
    if ev == "guard":
        return e.get("kind", "")
    if ev == "node_end":
        return f"{e.get('ms')} ms"
    if ev == "run_end":
        r = e["response"]
        return f"DECISION {r['decision']} - cites {[x['guideline_id'] for x in r['reasons']]} flags {r['flags']}"
    if ev == "run_start":
        return f"{e.get('case_id')} mode={e.get('mode')} model={e.get('model')}"
    return e.get("reason", "") or ""


def render_trace_html(events: list[dict]) -> str:
    rows = []
    colors = {"tool_call": "#2563eb", "llm_call": "#7c3aed", "guard": "#b45309", "fallback": "#b91c1c",
              "run_end": "#047857", "hitl_pause": "#be185d", "hitl_resume": "#be185d"}
    for e in events:
        if e["event"] == "node_start":
            continue
        body = {k: v for k, v in e.items() if k not in ("seq", "ts", "trace_id", "event", "node", "elapsed_ms")}
        c = colors.get(e["event"], "#475569")
        rows.append(
            f"<details><summary><span class=t>{e['elapsed_ms']:.0f} ms</span><span class=n>{html.escape(str(e.get('node')))}</span>"
            f"<span class=e style='color:{c}'>{e['event']}</span> {html.escape(_headline(e))}</summary>"
            f"<pre>{html.escape(json.dumps(body, indent=2, default=str))}</pre></details>")
    tid = events[0]["trace_id"] if events else ""
    return f"""<!doctype html><html><head><meta charset=utf-8><title>Trace {tid}</title><style>
body{{font:14px system-ui,sans-serif;margin:24px;max-width:1100px;color:#0f172a}}h1{{font-size:18px}}
details{{border-bottom:1px solid #e2e8f0;padding:6px 0}}summary{{cursor:pointer}}
.t{{display:inline-block;width:80px;color:#64748b}}.n{{display:inline-block;width:130px;font-weight:600}}
.e{{display:inline-block;width:100px;font-weight:600}}pre{{background:#f8fafc;padding:10px;overflow:auto;font-size:12px}}
</style></head><body><h1>Run trace {tid}</h1>{''.join(rows)}</body></html>"""
