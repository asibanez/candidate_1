"""Run logging. Every run gets a trace_id and an append-only JSONL file in runs/.

Each line is one event: node start/end, tool call (with attempts, latency, status, response),
LLM call (prompt, raw response, token usage, latency), guard interventions, and the decision.
That file is the audit record used to explain any decision after the fact.
"""
from __future__ import annotations

import json
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import get_settings

_REGISTRY: dict[str, "TraceLogger"] = {}
_REG_LOCK = threading.Lock()


def _jsonable(obj: Any) -> Any:
    try:
        json.dumps(obj)
        return obj
    except TypeError:
        if hasattr(obj, "model_dump"):
            return obj.model_dump()
        if isinstance(obj, dict):
            return {str(k): _jsonable(v) for k, v in obj.items()}
        if isinstance(obj, (list, tuple, set)):
            return [_jsonable(v) for v in obj]
        return repr(obj)


class TraceLogger:
    def __init__(self, trace_id: str, runs_dir: Path | None = None):
        self.trace_id = trace_id
        self.path = (runs_dir or get_settings().runs_dir) / f"{trace_id}.jsonl"
        self._lock = threading.Lock()
        self._seq = self._existing_lines()
        self._t0 = time.perf_counter()

    def _existing_lines(self) -> int:
        if self.path.exists():
            with self.path.open(encoding="utf-8") as f:
                return sum(1 for _ in f)
        return 0

    def log(self, event: str, node: str | None = None, **data: Any) -> None:
        with self._lock:
            self._seq += 1
            rec = {
                "seq": self._seq,
                "ts": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
                "elapsed_ms": round((time.perf_counter() - self._t0) * 1000, 1),
                "trace_id": self.trace_id,
                "event": event,
                "node": node,
                **{k: _jsonable(v) for k, v in data.items()},
            }
            with self.path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(rec, default=str) + "\n")


def new_trace_id() -> str:
    return uuid.uuid4().hex[:16]


def get_tracer(trace_id: str) -> TraceLogger:
    with _REG_LOCK:
        t = _REGISTRY.get(trace_id)
        if t is None:
            t = TraceLogger(trace_id)
            _REGISTRY[trace_id] = t
        return t


def read_trace(trace_id: str) -> list[dict]:
    p = get_settings().runs_dir / f"{trace_id}.jsonl"
    if not p.exists():
        raise FileNotFoundError(trace_id)
    return [json.loads(line) for line in p.read_text(encoding="utf-8").splitlines() if line.strip()]
