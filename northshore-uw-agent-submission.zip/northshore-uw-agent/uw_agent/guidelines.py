"""Loads the underwriting guidelines and indexes them by section number.

The index is used to (a) validate that every citation refers to a real section,
(b) give the LLM nodes the exact text of the sections they are explaining, and
(c) show section titles in responses and traces.
"""
from __future__ import annotations

import re
from functools import lru_cache
from pathlib import Path

from .config import get_settings

_ITEM = re.compile(r"^\s*(?:-\s*)?\*\*(\d+\.\d+)\s*([^*]*?)\*\*\s*(.*)$")
_HEAD = re.compile(r"^##\s+(\d+)\.\s+(.*)$")


class Guidelines:
    def __init__(self, path: Path):
        self.path = path
        self.text = path.read_text(encoding="utf-8")
        self.version = None
        m = re.search(r"Version\s+([\d.]+)", self.text)
        if m:
            self.version = m.group(1)
        self.sections: dict[str, dict] = {}
        current_head = None
        for line in self.text.splitlines():
            h = _HEAD.match(line)
            if h:
                current_head = h.group(1)
                self.sections[current_head] = {"id": current_head, "title": h.group(2).strip(), "text": ""}
                continue
            m = _ITEM.match(line)
            if m:
                sid, title, body = m.group(1), m.group(2).strip().rstrip(".:"), m.group(3).strip()
                self.sections[sid] = {"id": sid, "title": title or f"Section {sid}", "text": body, "parent": current_head}

    def title(self, sid: str) -> str:
        sec = self.sections.get(sid)
        return sec["title"] if sec else sid

    def snippet(self, ids: list[str]) -> str:
        out = []
        for sid in sorted(set(ids), key=lambda s: [int(x) for x in s.split(".")]):
            sec = self.sections.get(sid)
            if sec:
                out.append(f"{sid} {sec['title']}: {sec['text']}".strip())
        return "\n".join(out)

    def is_valid(self, sid: str) -> bool:
        return sid in self.sections


@lru_cache(maxsize=1)
def get_guidelines() -> Guidelines:
    return Guidelines(get_settings().guidelines_path)
