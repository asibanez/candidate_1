"""Runtime configuration, read from environment variables (and an optional .env file)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

try:  # optional convenience
    from dotenv import load_dotenv

    load_dotenv()
except Exception:  # pragma: no cover
    pass

ROOT = Path(__file__).resolve().parent.parent


def _bool(name: str, default: bool) -> bool:
    v = os.getenv(name)
    if v is None:
        return default
    return v.strip().lower() in {"1", "true", "yes", "on"}


def _default_provider() -> str:
    explicit = os.getenv("LLM_PROVIDER")
    if explicit:
        return explicit.strip().lower()
    if os.getenv("ANTHROPIC_API_KEY"):
        return "anthropic"
    if os.getenv("OPENAI_API_KEY"):
        return "openai"
    return "none"


DEFAULT_MODELS = {
    "anthropic": "claude-sonnet-5-5",
    "openai": "gpt-4.1-mini",
    "ollama": "qwen2.5:7b-instruct",
    "none": "deterministic",
}


@dataclass
class Settings:
    # Mock enterprise services
    services_base_url: str = field(default_factory=lambda: os.getenv("SERVICES_BASE_URL", "http://127.0.0.1:8001"))
    services_api_key: str = field(default_factory=lambda: os.getenv("SERVICES_API_KEY", "nshi-dev-key-2026"))
    service_timeout_s: float = field(default_factory=lambda: float(os.getenv("SERVICE_TIMEOUT_S", "5")))
    service_max_attempts: int = field(default_factory=lambda: int(os.getenv("SERVICE_MAX_ATTEMPTS", "6")))
    service_backoff_base_s: float = field(default_factory=lambda: float(os.getenv("SERVICE_BACKOFF_BASE_S", "0.2")))

    # LLM
    llm_provider: str = field(default_factory=_default_provider)  # anthropic | openai | ollama | none
    llm_model: str = field(default_factory=lambda: os.getenv("LLM_MODEL", ""))
    llm_temperature: float = field(default_factory=lambda: float(os.getenv("LLM_TEMPERATURE", "0")))
    llm_max_tool_rounds: int = field(default_factory=lambda: int(os.getenv("LLM_MAX_TOOL_ROUNDS", "4")))

    # Our API
    api_key: str = field(default_factory=lambda: os.getenv("UW_API_KEY", "uw-demo-key"))
    hitl_default: bool = field(default_factory=lambda: _bool("HITL_ENABLED", False))

    # Paths
    guidelines_path: Path = field(
        default_factory=lambda: Path(os.getenv("GUIDELINES_PATH", ROOT / "kit/guidelines/homeowners_underwriting_guidelines.md"))
    )
    runs_dir: Path = field(default_factory=lambda: Path(os.getenv("RUNS_DIR", ROOT / "runs")))

    def __post_init__(self) -> None:
        if not self.llm_model:
            self.llm_model = DEFAULT_MODELS.get(self.llm_provider, "")
        self.runs_dir.mkdir(parents=True, exist_ok=True)

    @property
    def llm_enabled(self) -> bool:
        return self.llm_provider != "none"


_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings


def override_settings(**kwargs) -> Settings:
    """Used by the eval harness / tests to switch provider etc. at runtime."""
    global _settings
    s = Settings()
    for k, v in kwargs.items():
        setattr(s, k, v)
    if "llm_provider" in kwargs and "llm_model" not in kwargs:
        s.llm_model = os.getenv("LLM_MODEL") or DEFAULT_MODELS.get(s.llm_provider, "")
    _settings = s
    return s
