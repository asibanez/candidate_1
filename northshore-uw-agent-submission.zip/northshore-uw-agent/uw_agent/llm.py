"""Model provider factory and a logged invoke helper.

LLM_PROVIDER = anthropic | openai | ollama | none   (auto-detected from API keys if unset)
LLM_MODEL    = provider model name (sensible default per provider)
"""
from __future__ import annotations

import time
from typing import Any

from .config import get_settings
from .tracing import TraceLogger

_MODEL_CACHE: dict[tuple, Any] = {}


def get_chat_model():
    s = get_settings()
    if not s.llm_enabled:
        return None
    key = (s.llm_provider, s.llm_model, s.llm_temperature)
    if key in _MODEL_CACHE:
        return _MODEL_CACHE[key]
    if s.llm_provider == "anthropic":
        from langchain_anthropic import ChatAnthropic

        m = ChatAnthropic(model=s.llm_model, temperature=s.llm_temperature, max_tokens=4096, timeout=60, max_retries=3)
    elif s.llm_provider == "openai":
        from langchain_openai import ChatOpenAI

        m = ChatOpenAI(model=s.llm_model, temperature=s.llm_temperature, timeout=60, max_retries=3)
    elif s.llm_provider == "ollama":
        from langchain_ollama import ChatOllama

        m = ChatOllama(model=s.llm_model, temperature=s.llm_temperature)
    else:
        raise ValueError(f"Unknown LLM_PROVIDER '{s.llm_provider}' (use anthropic, openai, ollama or none)")
    _MODEL_CACHE[key] = m
    return m


def structured(llm, schema):
    """Structured output that works across providers. OpenAI's strict json_schema mode rejects optional
    fields with defaults, so use function calling there; Anthropic/Ollama use their default (tool calling)."""
    if get_settings().llm_provider == "openai":
        return llm.with_structured_output(schema, include_raw=True, method="function_calling")
    return llm.with_structured_output(schema, include_raw=True)


def _msg_dump(m: Any) -> dict:
    if isinstance(m, dict):
        return m
    d = {"role": getattr(m, "type", "?"), "content": getattr(m, "content", str(m))}
    if getattr(m, "tool_calls", None):
        d["tool_calls"] = m.tool_calls
    if getattr(m, "tool_call_id", None):
        d["tool_call_id"] = m.tool_call_id
    return d


def logged_invoke(runnable, messages: list, tracer: TraceLogger | None, node: str, purpose: str):
    """Invoke a chat model / structured-output runnable and record prompt, response, usage, latency."""
    s = get_settings()
    t0 = time.perf_counter()
    err = None
    out = None
    try:
        out = runnable.invoke(messages)
        return out
    except Exception as e:  # logged then re-raised; callers fall back to deterministic logic
        err = f"{type(e).__name__}: {e}"
        raise
    finally:
        if tracer:
            raw = out.get("raw") if isinstance(out, dict) else out
            parsed = out.get("parsed") if isinstance(out, dict) else None
            usage = getattr(raw, "usage_metadata", None) if raw is not None else None
            tracer.log(
                "llm_call",
                node=node,
                purpose=purpose,
                provider=s.llm_provider,
                model=s.llm_model,
                latency_ms=round((time.perf_counter() - t0) * 1000, 1),
                prompt=[_msg_dump(m) for m in messages],
                response=_msg_dump(raw) if raw is not None else None,
                parsed=parsed.model_dump() if hasattr(parsed, "model_dump") else parsed,
                parsing_error=str(out.get("parsing_error")) if isinstance(out, dict) and out.get("parsing_error") else None,
                usage=dict(usage) if usage else None,
                error=err,
            )
