"""Entry points used by the API, the CLI and the eval harness."""
from __future__ import annotations

import threading

from langgraph.types import Command

from .config import get_settings
from .graph import build_response, get_graph
from .tracing import get_tracer, new_trace_id

_PENDING: dict[str, dict] = {}  # trace_id -> summary of runs paused for human review
_LOCK = threading.Lock()


def default_mode() -> str:
    return "llm" if get_settings().llm_enabled else "deterministic"


def run_case(case: dict, mode: str | None = None, hitl: bool | None = None, trace_id: str | None = None) -> dict:
    s = get_settings()
    trace_id = trace_id or new_trace_id()
    mode = mode or default_mode()
    hitl = s.hitl_default if hitl is None else hitl
    graph = get_graph()
    cfg = {"configurable": {"thread_id": trace_id}, "recursion_limit": 50}
    try:
        state = graph.invoke({"trace_id": trace_id, "case": case, "mode": mode, "hitl": hitl}, cfg)
    except Exception as e:
        get_tracer(trace_id).log("run_error", error=f"{type(e).__name__}: {e}")
        raise
    if state.get("__interrupt__"):
        resp = build_response(state, status="PENDING_REVIEW")
        resp["review_endpoint"] = f"/v1/reviews/{trace_id}"
        with _LOCK:
            _PENDING[trace_id] = {"trace_id": trace_id, "case_id": case.get("case_id"), "reasons": resp["reasons"],
                                  "other_findings": resp["other_findings"], "flags": resp["flags"]}
        return resp
    return state["response"]


def resume_case(trace_id: str, review: dict) -> dict:
    with _LOCK:
        if trace_id not in _PENDING:
            raise KeyError(trace_id)
    graph = get_graph()
    cfg = {"configurable": {"thread_id": trace_id}, "recursion_limit": 50}
    state = graph.invoke(Command(resume=review), cfg)
    with _LOCK:
        _PENDING.pop(trace_id, None)
    return state["response"]


def pending_reviews() -> list[dict]:
    with _LOCK:
        return list(_PENDING.values())
