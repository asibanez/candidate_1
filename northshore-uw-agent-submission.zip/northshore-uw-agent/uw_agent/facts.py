"""Facts: what we believe about the risk, where each belief comes from, and how conflicts resolve.

Every fact is collected as one or more *candidates*, each tagged with its source.
Reconciliation applies guideline 9.1: the most authoritative source with a value wins
    inspection (1) > third_party (2) > application (3) > agent_notes (4)
All candidates are kept, so the trace shows what each source said and why one won.
"""
from __future__ import annotations

from datetime import date
from typing import Any

SOURCE_RANK = {"inspection": 1, "third_party": 2, "application": 3, "agent_notes": 4}

# fact key -> (type, description). Types: bool, num, str, enum:<a|b|c>
FACT_SPEC: dict[str, tuple[str, str]] = {
    "occupancy": ("enum:owner_primary|owner_secondary|tenant|vacant", "who lives in the dwelling"),
    "months_unoccupied": ("num", "consecutive months currently unoccupied"),
    "str_nights_per_year": ("num", "short-term-rental nights per year (stays < 30 days)"),
    "existing_damage": ("bool", "unrepaired damage present, incl. active roof leaks"),
    "electrical.knob_and_tube": ("bool", "active knob-and-tube wiring present"),
    "electrical.panel_type": ("enum:circuit_breaker|fuse", "electrical panel type"),
    "electrical.amps": ("num", "electrical service amperage"),
    "oil_tank.present": ("bool", "heating-oil tank present"),
    "oil_tank.location": ("enum:underground|basement|above_ground", "oil tank location"),
    "oil_tank.age_years": ("num", "oil tank age in years"),
    "coverage_a": ("num", "requested Coverage A (dwelling) limit in USD"),
    "roof.material": ("str", "roof covering material"),
    "roof.age_years": ("num", "roof age in years at submission"),
    "roof.condition": ("enum:good|fair|poor", "roof condition rating from an inspection"),
    "pool.present": ("bool", "swimming pool present"),
    "pool.type": ("enum:in_ground|above_ground", "pool type"),
    "pool.fence_height_ft": ("num", "pool fence height in feet"),
    "pool.self_latching_gate": ("bool", "pool fence has a self-latching gate"),
    "pool.diving_board_or_slide": ("bool", "pool has a diving board or slide"),
    "trampoline.present": ("bool", "trampoline present"),
    "trampoline.safety_net": ("bool", "trampoline has a safety net enclosure"),
    "dogs.present": ("bool", "any dog on the premises"),
    "dogs.bite_history": ("bool", "any dog on premises has a bite history (prior bite or bite claim)"),
    "heating.primary": ("str", "primary heat source"),
    "wood_stove.present": ("bool", "supplemental wood/pellet stove present"),
    "wood_stove.professionally_installed": ("bool", "stove professionally installed"),
    "wood_stove.ul_listed": ("bool", "stove UL-listed"),
    "coast_distance_ft": ("num", "distance to coast in feet"),
    "replacement_cost": ("num", "replacement cost estimate in USD"),
    "flood_zone": ("str", "FEMA flood zone"),
}

# Facts the LLM / regex extractor may report from free text (agent notes, inspection report).
EXTRACTABLE_FACTS = [
    k for k in FACT_SPEC if k not in {"coverage_a", "coast_distance_ft", "replacement_cost", "flood_zone", "roof.condition"}
]


# ---------------------------------------------------------------- normalisation
ASPHALT = {"asphalt_shingle", "asphalt", "composition_shingle", "composition", "architectural_shingle", "3_tab_shingle", "shingle"}
LONG_LIFE = {"metal", "standing_seam_metal", "slate", "clay_tile", "concrete_tile", "tile"}


def norm_token(v: Any) -> Any:
    if isinstance(v, str):
        return v.strip().lower().replace("-", "_").replace(" ", "_")
    return v


def roof_family(material: str | None) -> str | None:
    if material is None:
        return None
    m = norm_token(material)
    if m in ASPHALT or "asphalt" in m or "composition" in m:
        return "asphalt"
    if m in LONG_LIFE or any(x in m for x in ("metal", "slate", "tile")):
        return "long_life"
    return "other"


def is_wood_or_pellet(heat: str | None) -> bool:
    if not heat:
        return False
    h = norm_token(heat)
    return "wood" in h or "pellet" in h


def coerce(fact: str, value: Any) -> Any:
    """Coerce a raw value to the fact's type. Returns None if it can't be coerced."""
    if value is None:
        return None
    typ = FACT_SPEC[fact][0]
    if isinstance(value, str) and value.strip().lower() in {"", "null", "none", "unknown", "n/a"}:
        return None
    try:
        if typ == "bool":
            if isinstance(value, bool):
                return value
            s = str(value).strip().lower()
            if s in {"true", "yes", "y", "1", "present"}:
                return True
            if s in {"false", "no", "n", "0", "absent"}:
                return False
            return None
        if typ == "num":
            if isinstance(value, bool):
                return None
            return float(str(value).replace(",", "").replace("$", "").strip())
        if typ.startswith("enum:"):
            allowed = typ[5:].split("|")
            v = norm_token(value)
            aliases = {
                "breaker": "circuit_breaker", "circuit_breakers": "circuit_breaker", "fuse_box": "fuse", "fuses": "fuse",
                "inground": "in_ground", "aboveground": "above_ground", "above_ground_pool": "above_ground",
                "owner": "owner_primary", "owner_occupied": "owner_primary", "primary": "owner_primary",
                "secondary": "owner_secondary", "rental": "tenant", "tenant_occupied": "tenant", "renter": "tenant",
                "buried": "underground", "in_basement": "basement", "outdoor": "above_ground", "outside": "above_ground",
            }
            v = aliases.get(v, v)
            return v if v in allowed else None
        return norm_token(value) if fact in {"roof.material", "heating.primary"} else str(value)
    except (TypeError, ValueError):
        return None


# ---------------------------------------------------------------- collection
def _cand(fact: str, value: Any, source: str, detail: str, quote: str | None = None) -> dict:
    return {"fact": fact, "value": coerce(fact, value), "raw": value, "source": source, "detail": detail, "quote": quote}


def application_candidates(app: dict) -> list[dict]:
    p = app.get("property", {}) or {}
    g = lambda d, *ks: _dig(d, ks)  # noqa: E731
    src, out = "application", []

    def add(fact, value, field_path):
        out.append(_cand(fact, value, src, f"application.{field_path}"))

    add("occupancy", p.get("occupancy"), "property.occupancy")
    add("months_unoccupied", p.get("months_unoccupied"), "property.months_unoccupied")
    add("str_nights_per_year", p.get("short_term_rental_nights_per_year"), "property.short_term_rental_nights_per_year")
    add("existing_damage", g(p, "existing_damage", "present"), "property.existing_damage.present")
    add("electrical.knob_and_tube", g(p, "electrical", "knob_and_tube"), "property.electrical.knob_and_tube")
    add("electrical.panel_type", g(p, "electrical", "panel_type"), "property.electrical.panel_type")
    add("electrical.amps", g(p, "electrical", "amps"), "property.electrical.amps")
    add("oil_tank.present", g(p, "oil_tank", "present"), "property.oil_tank.present")
    add("oil_tank.location", g(p, "oil_tank", "location"), "property.oil_tank.location")
    add("oil_tank.age_years", g(p, "oil_tank", "age_years"), "property.oil_tank.age_years")
    add("coverage_a", g(app, "coverage", "coverage_a"), "coverage.coverage_a")
    add("roof.material", g(p, "roof", "material"), "property.roof.material")
    add("roof.age_years", g(p, "roof", "age_years"), "property.roof.age_years")
    for k in ("present", "type", "fence_height_ft", "self_latching_gate", "diving_board_or_slide"):
        add(f"pool.{k}", g(p, "pool", k), f"property.pool.{k}")
    add("trampoline.present", g(p, "trampoline", "present"), "property.trampoline.present")
    add("trampoline.safety_net", g(p, "trampoline", "safety_net"), "property.trampoline.safety_net")
    dogs = p.get("dogs")
    if isinstance(dogs, list):
        add("dogs.present", len(dogs) > 0, "property.dogs")
        bites = [d.get("bite_history") for d in dogs if isinstance(d, dict)]
        bite = True if any(b is True for b in bites) else (None if any(b is None for b in bites) else False)
        add("dogs.bite_history", bite if dogs else False, "property.dogs[*].bite_history")
    add("heating.primary", g(p, "heating", "primary"), "property.heating.primary")
    for k in ("present", "professionally_installed", "ul_listed"):
        add(f"wood_stove.{k}", g(p, "heating", "wood_stove", k), f"property.heating.wood_stove.{k}")
    return out


def service_candidates(app: dict, evidence: dict) -> list[dict]:
    out: list[dict] = []
    submitted = date.fromisoformat(app["submitted_date"])
    prop = (evidence.get("property") or {})
    if prop.get("status") == "ok":
        d = prop["data"]
        if d.get("roof_install_year"):
            age = submitted.year - int(d["roof_install_year"])
            out.append(_cand("roof.age_years", age, "third_party",
                             f"property service: roof_install_year={d['roof_install_year']} ({d.get('roof_source')}); "
                             f"{submitted.year}-{d['roof_install_year']}={age}"))
        out.append(_cand("coast_distance_ft", d.get("distance_to_coast_ft"), "third_party", "property service: distance_to_coast_ft"))
        out.append(_cand("replacement_cost", d.get("replacement_cost_estimate"), "third_party", "property service: replacement_cost_estimate"))
    cat = (evidence.get("cat_risk") or {})
    if cat.get("status") == "ok":
        out.append(_cand("flood_zone", cat["data"].get("fema_flood_zone"), "third_party", "cat-risk service: fema_flood_zone"))
    insp = (evidence.get("inspection") or {})
    if insp.get("status") == "ok":
        d = insp["data"]
        when = d.get("inspection_date")
        out.append(_cand("roof.condition", d.get("roof_condition"), "inspection", f"inspection {when}: roof_condition"))
        out.append(_cand("roof.age_years", d.get("roof_estimated_age_years"), "inspection", f"inspection {when}: roof_estimated_age_years"))
    return out


def _dig(d: Any, keys) -> Any:
    for k in keys:
        if not isinstance(d, dict):
            return None
        d = d.get(k)
    return d


# ---------------------------------------------------------------- reconciliation
def reconcile(candidates: list[dict]) -> dict[str, dict]:
    """Pick the most authoritative non-null candidate for each fact (guideline 9.1)."""
    facts: dict[str, dict] = {k: {"value": None, "source": None, "detail": None, "candidates": []} for k in FACT_SPEC}
    for c in candidates:
        if c["fact"] in facts:
            facts[c["fact"]]["candidates"].append(c)
    for k, f in facts.items():
        valued = [c for c in f["candidates"] if c["value"] is not None]
        if valued:
            best = min(valued, key=lambda c: SOURCE_RANK[c["source"]])
            f.update(value=best["value"], source=best["source"], detail=best["detail"], quote=best.get("quote"))
    return facts


def disagreements(facts: dict[str, dict]) -> list[dict]:
    """All facts where sources disagree (resolved by 9.1 or not) — for transparency and 9.2."""
    out = []
    for k, f in facts.items():
        vals = {(c["source"], _key(c["value"])) for c in f["candidates"] if c["value"] is not None}
        distinct = {v for _, v in vals}
        if len(distinct) > 1:
            out.append({
                "fact": k,
                "chosen": {"value": f["value"], "source": f["source"], "detail": f["detail"]},
                "candidates": [{"source": c["source"], "value": c["value"], "detail": c["detail"], "quote": c.get("quote")}
                               for c in f["candidates"] if c["value"] is not None],
            })
    return out


def _key(v):
    return round(v, 2) if isinstance(v, float) else v


def values(facts: dict[str, dict]) -> dict[str, Any]:
    return {k: f["value"] for k, f in facts.items()}
