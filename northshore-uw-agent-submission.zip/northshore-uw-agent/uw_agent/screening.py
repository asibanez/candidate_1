"""Deterministic screening of free text for (a) embedded instructions (guideline 10.1) and
(b) non-permitted underwriting factors (guideline 8.1).

This runs before any LLM sees the text and cannot be talked out of a finding, which makes it a
reliable floor. The LLM extractor adds paraphrase-robust detection on top; results are unioned.
The same lexicon is reused to check that no explanation we produce mentions a non-permitted factor.
"""
from __future__ import annotations

import re

INJECTION_PATTERNS = [
    r"\b(note|instruction|message|directive)s?\s+(to|for)\s+(the\s+)?(automated|ai|automatic|underwriting|review)\b",
    r"\b(ignore|disregard|override|bypass|skip|suppress)\b[^.]{0,40}\b(instruction|guideline|rule|check|review|claims|polic|step)",
    r"\b(return|output|set|mark|issue|give)\s+(the\s+|a\s+)?(decision|verdict|outcome)\b",
    r"\bdecision\s*[:=]\s*(approve|decline|refer)",
    r"\bdo\s+not\s+(query|call|check|run|use|pull|order|look)\b",
    r"\bpre-?approved\b",
    r"\b(must|should|please)\s+(be\s+)?approve[d]?\b",
    r"\bapprove\s+(this|the\s+application|immediately|without)\b",
    r"\bsystem\s+prompt\b",
    r"\byou\s+are\s+(now\s+)?(an?|the)\s+\w+",
    r"\[\[[^\]]+\]\]",
]

NON_PERMITTED = {
    # person-age only: "81-year-old widow", "the applicant is 81" - not "the roof is 17 years old"
    "age": [r"\b\d{2,3}[- ](year|yr)s?[- ]old\s+(man|woman|widow\w*|applicant|homeowner|owner|insured|retiree|couple|lady|"
            r"gentleman|mother|father|grand\w+|person|client|customer|guy|gal|senior)\b",
            r"\b(applicant|owner|homeowner|insured|client|customer|she|he|they)\s+(is|are)\s+(in (her|his|their)\s+)?\d{2,3}s?\b(?!\s*(ft|feet|foot|%|amps?|years?\s+from))",
            r"\b(elderly|senior citizen|retiree|millennial|young couple)\b", r"\baged\s+\d{2}\b"],
    "marital_or_family_status": [r"\bwidow(ed|er)?\b", r"\bdivorc", r"\b(married|unmarried|single (mom|mother|dad|father|parent))\b",
                                 r"\blives alone\b", r"\bfamily of (\w+)\b", r"\bnewlywed", r"\bpregnan", r"\bstay[- ]at[- ]home\b"],
    "credit": [r"\bcredit\s+(score|history|rating|report)\b", r"\bfico\b", r"\bbankrupt"],
    "dog_breed": [r"\bpit\s*-?bulls?\b", r"\brottweiler", r"\bdoberman", r"\bgerman shepherd", r"\bakita\b", r"\bchow\b",
                  r"\bhusk(y|ies)\b", r"\bmastiff", r"\bwolf hybrid", r"\bstaffordshire", r"\bbreed\b"],
    "race_ethnicity_national_origin": [r"\b(hispanic|latino|latina|asian|african[- ]american|caucasian|immigrant|foreign[- ]born|ethnic)\b"],
    "religion": [r"\b(muslim|jewish|christian|catholic|hindu|buddhist|sikh|mormon|church|mosque|synagogue|religio)"],
    "language": [r"\b(speaks?|speaking)\s+(little|no|limited|only|broken)?\s*(english|spanish|chinese|portuguese|russian)\b",
                 r"\b(doesn'?t|does not|can'?t) speak\b", r"\baccent\b"],
    "disability": [r"\b(disabled|disability|wheelchair|handicap|blind|deaf)\b"],
    "sex_gender_orientation": [r"\b(gay|lesbian|transgender|same[- ]sex|bisexual)\b"],
    "occupation": [r"\b(unemployed|occupation|works as an?|employed as|is an? (nurse|teacher|doctor|lawyer|police officer|firefighter|"
                   r"truck driver|contractor|engineer|student))\b"],
    "income": [r"\b(income|salary|makes \$|earns|wealthy|low[- ]income|high[- ]income|net worth)\b"],
    "neighborhood_demographics": [r"\b(bad|rough|sketchy|changing|nice|good|safe|unsafe)\s+(neighbou?rhood|area|part of town)\b",
                                  r"\bdemographic"],
}

_sent_split = re.compile(r"(?<=[.!?])\s+|\n+")


def _sentence(text: str, start: int, end: int) -> str:
    left = max(text.rfind(". ", 0, start), text.rfind("\n", 0, start))
    left = 0 if left < 0 else left + 1
    m = re.search(r"[.!?\n]", text[end:])
    right = len(text) if not m else end + m.end()
    return text[left:right].strip()


def find_injections(text: str) -> list[dict]:
    out, seen = [], set()
    for pat in INJECTION_PATTERNS:
        for m in re.finditer(pat, text or "", flags=re.I):
            q = _sentence(text, m.start(), m.end())
            if q not in seen:
                seen.add(q)
                out.append({"kind": "embedded_instruction", "quote": q, "pattern": pat, "detector": "regex"})
    return out


def find_non_permitted(text: str) -> list[dict]:
    out, seen = [], set()
    for cat, pats in NON_PERMITTED.items():
        for pat in pats:
            for m in re.finditer(pat, text or "", flags=re.I):
                key = (cat, m.group(0).lower())
                if key not in seen:
                    seen.add(key)
                    out.append({"kind": "non_permitted_factor", "category": cat, "match": m.group(0),
                                "quote": _sentence(text, m.start(), m.end()), "detector": "regex"})
    return out


def mentions_non_permitted(text: str) -> list[str]:
    """Used as an output guard on explanations we generate."""
    return sorted({f["category"] for f in find_non_permitted(text)})
